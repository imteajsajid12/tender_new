@extends('layouts.admin.header')
@section('content')

    <?php
    /*$metaJson1 = unserialize($application->p1_meta['metaJson']);
	$metaJson2 = unserialize($application->p2_meta['metaJson']);
	$metaJson3 = unserialize($application->p3_meta['metaJson']);*/
    try {
        $metaJson5 = unserialize($application?->p5_meta['metaJson']) ?? [];
    } catch (\Throwable $th) {
        //throw $th;
        $metaJson5 = [];
    }
    // function showTitle($page) {
    // 	return $page;
    // }
    ?>
    <style>
        .btn-danger {
            color: #fff;
            background-color: #e3342f;
            border-color: #e3342f;
        }

        .input-group.first .input-group-append {
            display: none !important;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.js">
    </script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.css">
    <div class="content single-app">
        <main>
            <input type="hidden" name="appid_input" id="appid_input" value="{{ $application->id }}">
            <div class="card-header single-card-header">
                <div class="h-right-bar">
                    <span>{{ $application->tname }}</span>
                    <a href="/admin/tenders/requestsorted/all/{{ $application->tenderid }}"
                        class="paginate apps-link rectangle">
                        <img src="{{ asset('img/right-back.png') }}">
                    </a>
                </div>
            </div>
            <div class="apps-card-body">
                @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                @endif
                <?php
                $p_e = $application->st > 2 ? 'pointer-events: none' : '';
                $p_1 = isset($metaJson5) ? 'visibility: hidden;' : 'text-align: right; visibility: visible;';
                ?>
                <div class="container_child">
                    @if (!empty($application))
                        <table style="width: 100%" class="align-right">
                            <tr>
                                <td>
                                    <div class="app-head">מס’ פניה:</div>
                                    <div class="app-head-info" confirm-icon>
                                        {{ '2020-' . (100 + $application->decision->id) }}
                                        {{ $application->decision->generated_dec_id }}
                                    </div>
                                </td>
                                <td>
                                    <div class="app-head">שם הטופס:</div>
                                    <div class="app-head-info" confirm-icon>{{ $application->tname }}</div>
                                </td>
                                <td>
                                    <div class="app-head">תאריך פנייה:</div>
                                    <div class="app-head-info">{{ date('d/m/Y', strtotime($application->send_date)) }}</div>
                                </td>
                                <td>
                                    <div class="app-head">שם הפונה:</div>
                                    <div class="app-head-info">{{ $application->decision->applicant_name }}</div>
                                </td>
                                <td>
                                    <div class="app-head">סטטוס:</div>
                                    <div class="app-head-info">{{ $statuses[$application->status] ?? $application->status }}
                                    </div>
                                </td>
                            </tr>
                        </table>
                        @if (!empty($application->p1_meta['metaJson']) || !empty($application->p5_meta['metaJson']))
                            <?php
                            
                            ?>
                        @else
                            <h3 style="color: red">לא ניתן לבצע פעולה נוספת, ישנם נתונים חסרים</h3>
                        @endif
                    @else
                        No application
                    @endif
                    <div style="margin-top: 60px;overflow: hidden;">
                        <div class="sky-rtl doc-name" style="margin-top: 0"> טופס הבקשה: </div>
                        <div>
                            <?php
						$length = count($allforms);
						if (!empty($allforms))
						{

						for ($i=0; $i<$length; $i++)
						{

						$file = $allforms[$i];
						if (!isset($file->url)) continue;
						$file_1 = '';
						$file_name = '';
						$tclass = '';

						?>
                            <div class="file-content">
                                <span class="file-title"> שאלון אישי למועמד </span>
                                <a href="{{ asset('upload/' . $file->url) }}" target="_blank" rel="noopener noreferrer"
                                    style="margin-bottom: 5px" title="{{ $file_1 }}">
                                    <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                    <?php if ($file->status == 1) {
                                        $tclass = 'approve';
                                    } elseif ($file->status == 2) {
                                        $tclass = 'cancel';
                                    } else {
                                        $tclass = '';
                                    } ?>
                                    <span class="type {{ $tclass }}"></span>
                                </a>
                                <span class="doc-filename">{{ $file_name }}</span>
                                <?php
                                if ($file->status == 3) {
                                    echo '<span class="doc-filename replace">ממתין לאישור</span>';
                                }
                                if ($file->status == 4) {
                                    echo '<span class="doc-filename replace">נשלחה בקשה למסמך אחר</span>';
                                }
                                ?>
                                @if (\App\User::check_auth_user_AppPermission2($application, 2))
                                    <div>
                                        <button class="apps-btn" id="cancel_{{ $file->id }}"
                                            onclick="cancel_file_tk(this, {{ $file->id }} )"
                                            style="{{ $p_e }}">דחה
                                        </button>
                                    </div>
                                    <div>
                                        <button class="apps-btn" onclick="approve_file_tk(this, {{ $file->id }} )"
                                            style="{{ $p_e }}"> אשר
                                        </button>
                                    </div>
                                @endif
                            </div>
                            <?php
						}
						}
					?>
                        </div>
                    </div>

                    <div style="margin-top: 60px;overflow: hidden;">
                        @if (!empty($application->files))
                            <div style="text-align:right;margin-right:0px" class="doc-name">מסמכים לצירוף</div>
                            @foreach ($application->files as $file)
                                <?php
                                $isLegalAttach = strpos($file->file_name, 'email') !== false ? true : false;
                                $file_name = explode('^^', $file->file_name);
                                $file_1 = count($file_name) > 1 ? $file_name[1] : '';
                                //var_dump($formFileNames[$file_1]);
                                //var_dump($file_1);
                                ?>
                                @if (!$isLegalAttach)
                                    <div class="file-content">
                                        <span class="file-title"
                                            style="text-align: right">{{ isset($formFileNames[$file_1]) ? $formFileNames[$file_1] : $file_1 }}</span>
                                        <a href="{{ asset('upload/' . $file->url) }}" target="_blank"
                                            rel="noopener noreferrer" style="margin-bottom: 5px"
                                            title="{{ $file_name[0] }}">
                                            <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                            <?php
                                            if ($file->status == 1) {
                                                $tclass = 'approve';
                                            } elseif ($file->status == 2) {
                                                $tclass = 'cancel';
                                            } else {
                                                $tclass = '';
                                            }
                                            ?>
                                            <span class="type {{ $tclass }}"></span>
                                        </a>
                                        <span class="doc-filename">{{ $file_name[0] }}</span>
                                        <?php
                                        if ($file->status == 3) {
                                            echo '<span class="doc-filename replace">ממתין לאישור</span>';
                                        }
                                        if ($file->status == 4) {
                                            echo '<span class="doc-filename replace">נשלחה בקשה למסמך אחר</span>';
                                        }
                                        ?>
                                        @if (\App\User::check_auth_user_AppPermission2($application, 2))
                                            <div>
                                                <button class="apps-btn" id="cancel_{{ $file->id }}"
                                                    onclick="cancel_file_tk(this, {{ $file->id }} )"
                                                    style="{{ $p_e }}">דחה
                                                </button>
                                            </div>
                                            <div>
                                                <button class="apps-btn"
                                                    onclick="approve_file_tk(this, {{ $file->id }} )"
                                                    style="{{ $p_e }}"> אשר
                                                </button>
                                            </div>
                                        @endif
                                    </div>
                                @endif
                            @endforeach
                        @endif
                        <div class="file-content">
                            <span class="file-title" style="font-weight: 700;text-align: right;font-size:0.9em">מסמך
                                אחר</span>
                            <a href="#" onclick="requestNewFile(<?php echo $application->id; ?>)">
                                <div
                                    style="width:130px;height:130px;background:#d3d3d3;display:flex;align-items:center;justify-content:center;">

                                    <img style="width:56px;height:76px" src="/img/newfile.png">
                                </div>
                            </a>
                            <button class="apps-btn" style="width:100%;margin-top:5px;"
                                onclick="showRequestNewFile(<?php echo $application->id; ?>)">בקשה למסמך אחר
                            </button>
                            <div id="files_comment"
                                style="display:none;margin-top:50px;width:400px;height:300px; border:thin solid #4c9d4c">
                                <textarea id="files_comment_data" type="text" style="width:100%;height:100%"></textarea>
                                <button class="apps-btn" style="width:100%;margin-top:0;margin-left:0"
                                    onclick="requestNewFile(<?php echo $application->id; ?>)">בקשה למסמך אחר
                                </button>
                            </div>
                        </div>
                    </div>
                    @if ($ifnotapprovedfiles === 'nono' || $ifnotapprovedfiles == 0)
                        <div style="margin-top: 60px;overflow: hidden;">
                            <div class="mt-5 mb-5">
                                <h3 class="title">הגדרת נמענים להעתקים:</h3> <br>
                                <div class="input-control mr-0">
                                    <input class="typeahead form-control " type="text"
                                        placeholder="אנא הזינו את שם הנמען להגדרת העתק"
                                        data-path="/admin/users/autocomplete_users" autocomplete="off" id="typeahead"
                                        data-provide="typeahead">
                                    <button class="btn" style="display: inline-block;"
                                        id="add-user-inappp">הוסף</button>
                                    <button class="btn" style="display: inline-block;" id="add-user-outapp-form2">הוסף
                                        משתמש חיצוני</button>

                                </div><br>
                                <div class="typeahead_res">
                                    <?php echo $application->appusers; ?>
                                </div>
                                <div class="outer2"></div>
                            </div>
                        </div>
                    @endif
                </div>
                @if (
                    ($decision->decision_3 || $decision->decision_4) &&
                        !($decision->decision_5 != 1 && $decision->decision_6 != 1 && $decision->decision_rejectedbyuser != 1))
                    <div>
                        @if ($decision->decision_3)
                            <img src="/img/allok.png" />
                            <span class="captiogreen adminlighthdr">
                                אושר
                            </span>
                        @elseif ($decision->decision_4)
                            <img src="/img/nok.png" /><span class="captiored">
                                נדחה
                            </span>
                        @endif
                    </div>
                @endif
                @if (
                    $decision->decision_1 &&
                        !($decision->decision_5 != 1 && $decision->decision_6 != 1 && $decision->decision_rejectedbyuser != 1))
                    <span>אישור/ דחיה שלב א</span>
                @endif
                
                @if ($decfile)
                    <div style="display:flex;flex-direction: column" id="ifdecfile">
                        @foreach ($decfile as $decline)
                            <div style="margin-bottom: 20px;margin-left: 20px;width: 135px;">
                                @if (
                                    $decision->decision_1 &&
                                        ($decline->file_name === 'decisionapprove0.pdf' ||
                                            $decline->file_name === 'decisionapprove0a.pdf' ||
                                            $decline->file_name === 'decisionreject0.pdf' ||
                                            $decline->file_name === 'decisionreject0a.pdf' ||
                                            $decline->file_name === 'decisionreject0b.pdf' ||
                                            $decline->file_name === 'decisionreject0c.pdf' ||
                                            $decline->file_name === 'decisionreject0d.pdf' ||
                                            $decline->file_name === 'decisionreject1.pdf'))
                                    @if (
                                        $decline->file_name === 'decisionapprove0.pdf' ||
                                            $decline->file_name === 'decisionreject0.pdf' ||
                                            $decline->file_name === 'decisionreject0a.pdf' ||
                                            $decline->file_name === 'decisionreject0b.pdf' ||
                                            $decline->file_name === 'decisionreject0c.pdf' ||
                                            $decline->file_name === 'decisionreject0d.pdf' )
                                        <span style="font-weight: 700">אישור/ דחיה תנאי סף</span>
                                    @endif
                                    @if ($decline->file_name === 'decisionapprove1.pdf' || $decline->file_name === 'decisionreject1.pdf')
                                        <span style="font-weight: 700">אישור/ דחיה שלב א'</span>
                                    @endif
                                @endif
                                @if ($decline->file_name === 'decisionapprove0.pdf' || $decline->file_name === 'decisionapprove0a.pdf')
                                    <img src="/img/allok.png" />
                                    <span class="captiogreen adminlighthdr">
                                        אושר
                                    </span>
                                    <span class="file-title" style="font-weight: 400;text-align: right">אישור/ דחיה תנאי
                                        סף</span>
                                    <a href="{{ asset('upload/admin/' . $decline->url . '') }}" target="_blank"
                                        rel="noopener noreferrer" style="margin-bottom: 5px" title="decision.pdf">
                                        <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                        <span class="type pdf"></span>
                                    </a>
                                @endif
                                @php
                                    $decision_arr = (array) $decision;
                                @endphp
                                @if (
                                    $decline->file_name === 'decisionreject0.pdf' ||
                                        (!$decision->decision_4 &&
                                            ($decline->file_name === 'decisionreject0.pdf' ||
                                                $decline->file_name === 'decisionreject0a.pdf' ||
                                                $decline->file_name === 'decisionreject0b.pdf' ||
                                                $decline->file_name === 'decisionreject0c.pdf' 
                                                )) ||
                                        $decline->file_name === 'decisionreject1.pdf'
                                        )
                                    @if ($decline->file_name === 'decisionreject0b.pdf' && $decision_arr['2nd_invitation_rejected'])
                                        @continue
                                    @endif
                                    <img src="/img/nok.png" />
                                    <span class="captiored">
                                        נדחה
                                    </span>
                                    @if ($decline->file_name === 'decisionreject0b.pdf')
                                    <span class="" style="font-weight: 400;text-align: right">הסרת מועמדות</span>
                                    @else
                                    <span class="file-title" style="font-weight: 400;text-align: right">אישור/ דחיה תנאי
                                        סף</span>
                                    @endif
                                    <a href="{{ asset('upload/admin/' . $decline->url . '') }}" target="_blank"
                                        rel="noopener noreferrer" style="margin-bottom: 5px" title="decision.pdf">
                                        <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                        <span class="type pdf"></span>
                                    </a>
                                @endif

                            </div>
                        @endforeach
                    </div>
                    <div style="display:flex;flex-direction: column;align-items: flex-start;}}" id="ifdecfile2">
                        @if (
                            ($decfile &&
                                ($ifnotapprovedfiles === 'nono' || $ifnotapprovedfiles == 0) &&
                                !($decision->decision_1 || $decision->decision_1_a || $decision->decision_1_b || $decision->decision_2) &&
                                !($decision->decision_3 || $decision->decision_4) &&
                                ($decision->decision_5 != 1 && $decision->decision_6 != 1 && ($decision->decision_rejectedbyuser != 1))))
                            <div style="font-weight: 700; ">עמידה בתנאי סף</div>
                        @endif
                    </div>
                    <div style="text-align: right;display:flex;justify-content: space-between">
                        <div id="buttons-content">
                            @if (
                                ($decfile &&
                                    ($ifnotapprovedfiles === 'nono' || $ifnotapprovedfiles == 0) &&
                                    (!$decision->decision_1 &&
                                        !$decision->decision_1_a &&
                                        !$decision->decision_1_b &&
                                        !$decision->decision_2 &&
                                        !$decision->decision_3 &&
                                        !$decision->decision_4) &&
                                    !empty($metaJson5)
                                   ) 
                                    )
                                <div>
                                    <button type="button" class="apps-btn btn float-right ml-3"
                                        onclick="cond_details(this, 0,{{ $application->id }},[{'type':'select','class':'cancel_file_sel_approve','option':['--בחר--','ציפיות שכר','בלי ציפיות שכר']}, {'type':'textarea','class':'cancel_file_remarks','rows':'4'}], 'width: 697px;')">
                                        אישור
                                    </button>
                                    <button type="button" class="apps-btn btn float-right ml-3"
                                        onclick="cond_details(this, 1,{{ $application->id }},
[{'type':'select','class':'cancel_file_sel_reject','option':['--בחר--','דחייה רגילה']}, {'type':'textarea','class':'cancel_file_text','rows':'4'}], 'width: 697px;')">
                                        דחייה
                                    </button>
                                </div>
                            @elseif (($decision->decision_1 || $decision->decision_1_a || $decision->decision_1_b) && !$decision->decision_2 || $app_dec->last_committee_invitation_send || $decision->invitation_rejected_by_user)
                                @if (isset($email_msg))
                                    <div style="color: green;text-align: right;">{{ $email_msg }}</div>
                                @endif
                                <div style="font-weight: 700; ">זימון לראיון ראשוני/בחינה בכתב</div>
                                <div>
                                    <!--
                <div>
                 <label class="checkbox">
                  <input type="checkbox" name="interview" value="ראיון ראשוני" id="interview_yes">
                  <span class="virtual"></span>
                  <span style="font-weight: 500;">ראיון ראשוני</span>
                 </label>
                </div>
                -->
                                    <div data-show_type="interview_yes" style="display: none;">
                                        <div class="summons-user">
                                            <div class="input-control">
                                                <label>
                                                    <input type="text" name="interview_date" placeholder="הזן תאריך"
                                                        style="font-size: 12px;">
                                                </label>
                                            </div>
                                            <div class="input-control">
                                                <label>
                                                    <input type="text" name="interview_time" placeholder="הזן שעה"
                                                        style="font-size: 12px;">
                                                </label>
                                            </div>
                                            <div class="input-control">
                                                <label>
                                                    <input type="text" name="interview_place" placeholder="הזן מיקום"
                                                        style="font-size: 12px;">
                                                </label>
                                            </div>
                                            <div class="input-control">
                                                <label>
                                                    <textarea class="detail cancel_file_text" name="interview_msg" id="interview_msg" placeholder="הזן הערה"
                                                        style="font-size: 12px;" row="4"></textarea>
                                                    <button style="float: right;" type="button"
                                                        class="apps-btn btn ml-3"
                                                        onclick="send_email('interview',{{ $application->id }}, {{ $p5 }})">
                                                        שלח זימון
                                                    </button>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    @if (!empty($email_msg_interview) && !empty($interview_email))
                                        <div style="color: green;text-align: right;">{{ $email_msg_interview }}</div>
                                        <div class="mt-3 mb-2" style="overflow: hidden;padding-bottom: 10px"
                                            id="buttons-content">
                                            <h3 class="title" style="margin-bottom: 5px;">הזמנה לראיון</h3>
                                            <div class="file-content">
                                                <a href="{{ asset('upload/admin/' . $interview_email) }}" target="_blank"
                                                    rel="noopener noreferrer" style="margin-bottom: 5px">
                                                    <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                                </a>
                                                <span class="doc-filename">Answer.pdf</span>
                                            </div>
                                        </div>
                                    @endif
                                    @if ($tender->is_test_required)
                                        <div>
                                            <label class="checkbox">
                                                <input @checked($app_dec->selected_interview_time) type="checkbox" name="test"
                                                    value="בחינה בכתב" id="test_yes">
                                                <span class="virtual"></span>
                                                <span style="font-weight: 500;">בחינה בכתב</span>
                                            </label>
                                        </div>
                                        <div data-show_type="test_yes"
                                            style="display: {{ $app_dec->selected_interview_time ? 'block' : 'none' }};">
                                            <div class="summons-user" id="test_info_block">

                                                @if ($app_dec->approved_interview_time)
                                                    <div style="color: green;">
                                                        זמן שנבחר: {{ $app_dec->approved_interview_time }}
                                                    </div>
                                                @endif

                                                @if ($app_dec->selected_interview_time)
                                                    @foreach (json_decode($app_dec->selected_interview_time) as $date)
                                                        <div class="input-group date {{ $loop->first ? 'first' : '' }}">
                                                            <div class="input-group-append">
                                                                <button class="btn btn-danger input-delete-btn mt-0 p-0"
                                                                    data-type="date" style="min-width: 25px"
                                                                    type="button"><i class="fas fa-times"></i></button>
                                                            </div>
                                                            <input class="form-control" type="text"
                                                                value="{{ $date }}" name="test_date[]"
                                                                placeholder="הזן תאריך" style="font-size: 12px;">
                                                            <div class="input-group-prepend">
                                                                <button class="btn btn-info input-copy-btn mt-0 p-0"
                                                                    data-type="date" style="min-width: 25px"
                                                                    type="button"><i class="fas fa-plus"></i></button>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                @else
                                                    <div class="input-group date first">
                                                        <div class="input-group-append">
                                                            <button class="btn btn-danger input-delete-btn mt-0 p-0"
                                                                data-type="date" style="min-width: 25px"
                                                                type="button"><i class="fas fa-times"></i></button>
                                                        </div>
                                                        <input class="form-control" type="text" name="test_date[]"
                                                            placeholder="הזן תאריך" style="font-size: 12px;">
                                                        <div class="input-group-prepend">
                                                            <button class="btn btn-info input-copy-btn mt-0 p-0"
                                                                data-type="date" style="min-width: 25px"
                                                                type="button"><i class="fas fa-plus"></i></button>
                                                        </div>
                                                    </div>
                                                @endif

                                                <div class="date_extra_wrapper"></div>
                                                {{-- <div class="input-group time first">
											<div class="input-group-append">
												<button class="btn btn-danger input-delete-btn mt-0 p-0" data-type="time" style="min-width: 25px" type="button"><i class="fas fa-times"></i></button>
											</div>
											<input class="form-control" type="text" name="test_time[]" placeholder="הזן שעה" style="font-size: 12px;">
											<div class="input-group-prepend">
												<button class="btn btn-info input-copy-btn mt-0 p-0" data-type="time" style="min-width: 25px" type="button"><i class="fas fa-plus"></i></button>
											</div>
										</div> --}}
                                                <div class="time_extra_wrapper"></div>

                                                {{-- place --}}
                                                @if ($app_dec->approved_interview_place)
                                                    <div style="color: green;">
                                                        מיקום שנבחר {{ $app_dec->approved_interview_place }}
                                                    </div>
                                                @endif
                                                @if ($app_dec->selected_interview_place)
                                                    @foreach (json_decode($app_dec->selected_interview_place) as $place)
                                                        <div class="input-group place {{ $loop->first ? 'first' : '' }}">
                                                            <div class="input-group-append">
                                                                <button class="btn btn-danger input-delete-btn mt-0 p-0"
                                                                    data-type="place" style="min-width: 25px"
                                                                    type="button"><i class="fas fa-times"></i></button>
                                                            </div>
                                                            <input class="form-control" type="text"
                                                                value="{{ $place }}" name="test_place[]"
                                                                placeholder="הזן מיקום" style="font-size: 12px;">
                                                            <div class="input-group-prepend">
                                                                <button class="btn btn-info input-copy-btn mt-0 p-0"
                                                                    data-type="place"style="min-width: 25px"
                                                                    type="button"><i class="fas fa-plus"></i></button>
                                                            </div>

                                                        </div>
                                                    @endforeach
                                                @else
                                                    <div class="input-group place first">
                                                        <div class="input-group-append">
                                                            <button class="btn btn-danger input-delete-btn mt-0 p-0"
                                                                data-type="place" style="min-width: 25px"
                                                                type="button"><i class="fas fa-times"></i></button>
                                                        </div>
                                                        <input class="form-control" type="text" name="test_place[]"
                                                            placeholder="הזן מיקום" style="font-size: 12px;">
                                                        <div class="input-group-prepend">
                                                            <button class="btn btn-info input-copy-btn mt-0 p-0"
                                                                data-type="place"style="min-width: 25px" type="button"><i
                                                                    class="fas fa-plus"></i></button>
                                                        </div>

                                                    </div>
                                                @endif
                                                {{-- place --}}

                                                <div class="place_extra_wrapper">

                                                </div>
                                                <div class="input-control">
                                                    <label>
                                                        <textarea class="detail cancel_file_text" name="test_msg" id="test_msg" placeholder="הזן הערה"
                                                            style="font-size: 12px;" row="4"></textarea>
                                                        <button style="float: right;" type="button"
                                                            class="apps-btn btn ml-3"
                                                            onclick="send_email('test',{{ $application->id }}, {{ $p5 }})">
                                                            שלח זימון
                                                        </button>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                    @if (!empty($email_msg_test) && !empty($test_email))
                                        <div style="color: green;text-align: right;">{{ $email_msg_test }}</div>
                                        <div class="mt-3 mb-2" style="overflow: hidden;padding-bottom: 10px"
                                            id="buttons-content">
                                            <h3 class="title" style="margin-bottom: 5px;">בחינה בכתב</h3>
                                            <div class="file-content">
                                                <a href="{{ asset('upload/admin/' . $test_email) }}" target="_blank"
                                                    rel="noopener noreferrer" style="margin-bottom: 5px">
                                                    <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                                </a>
                                                <span class="doc-filename">Answer.pdf</span>
                                            </div>
                                        </div>
                                    @endif
                                </div>

                                <div id="show_committee" style=";">
                                    <label class="checkbox">
                                        <input @checked($app_dec->approved_committee_time) type="checkbox" name="committee" value="ועדת בחינה" id="committee_yes">
                                        <span class="virtual"></span>
                                        <span style="font-weight: 500;">ועדת בחינה</span>
                                    </label>
                                </div>
                                @if ($app_dec->committee_invitation_approved_time)
                                <div class="text-success">Approved 2nd Invitation DateTime: {{ $app_dec->committee_invitation_approved_time }}</div>
                                @endif
                                <div id="committee_block" data-show_type="committee_yes"
                                
                                @style([
                                    'display: none' => !$app_dec->approved_committee_time
                                ])>
                                    <div class="summons-user">
                                        <div class="input-control">
                                            <label>
                                                <input value="{{ now()->parse($app_dec->approved_committee_time)->format('d m, Y') }}" type="text" name="committee_date" placeholder="הזן תאריך"
                                                    style="font-size: 12px;">
                                            </label>
                                        </div>
                                        <div class="input-control">
                                            <label>
                                                <input value="{{ now()->parse($app_dec->approved_committee_time)->format('H:i') }}" type="text" name="committee_time" placeholder="הזן שעה"
                                                    style="font-size: 12px;">
                                            </label>
                                        </div>

                                        <div class="input-control">
                                            <label>
                                                <input value="{{ $app_dec->committee_selected_place }}" type="text" name="committee_place" placeholder="הזן מיקום"
                                                    style="font-size: 12px;">
                                            </label>

                                        </div>
                                        <div class="input-control">
                                            <label>
                                                <textarea class="detail cancel_file_text" name="committee_msg" id="committee_msg" placeholder="הזן הערה"
                                                    style="font-size: 12px;" row="4"></textarea>
                                                <button style="float: right;" type="button" class="apps-btn btn ml-3"
                                                    onclick="send_email('committee',{{ $application->id }}, {{ $p5 }})">
                                                    שלח זימון
                                                </button>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                @if (!empty($email_msg_committee) && !empty($committee_email))
                                    <div style="color: green;text-align: right;">{{ $email_msg_committee }}</div>
                                    <div class="mt-3 mb-2" style="overflow: hidden;padding-bottom: 10px"
                                        id="buttons-content">
                                        <h3 class="title" style="margin-bottom: 5px;">ועדת בחינה</h3>



                                        <div class="file-content">
                                            <a href="{{ asset('upload/admin/' . $committee_email) }}" target="_blank"
                                                rel="noopener noreferrer" style="margin-bottom: 5px">
                                                <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                            </a>
                                            <span class="doc-filename">Answer.pdf</span>
                                        </div>




                                        @if ($decision->decision_5)    
                                        <div
                                            style="display: flex; flex-direction: row; justify-content: space-between;  margin-bottom: 10px;">
                                            <div>
                                                <button type="button" class="apps-btn btn float-right ml-3"
                                                    onclick="document.getElementById('show_committee').style.display = 'block';">
                                                    שלח מכתב מתוקן לוועדת בחינה
                                                </button>
                                            </div>
                                            <div><!--&& empty($email_msg_committee) && empty($committee_email)-->
                                                <!--<button type="button" class="apps-btn btn float-right ml-3"
                   onclick="cond_details(this, 4,{{ $application->id }},
[{'type':'select','class':'cancel_file_sel_reject','option':['--בחר--','דחייה רגילה','ביטול ההליך המכרזי']},								 {'type':'textarea','class':'cancel_file_text','it':'text','placeholder':'הערות'}], 'width: 700px;')">
                  דחייה
                 </button>-->
                                            </div>
                                        </div>
                                        @endif
                                    </div>
                                @endif
                                @if (!empty($email_msg_committee_approve))
                                    <div style="color: green;text-align: right;">{{ $email_msg_committee_approve }}</div>
                                @endif
                                @foreach ($decfile as $decline)
                                    @if (
                                        !$decision->decision_2 &&
                                            !$decision->decision_3 &&
                                            !$decision->decision_3_a &&
                                            !$decision->decision_3_b &&
                                            !$decision->decision_4 &&
                                            ($decline->file_name == 'decisionapprove0.pdf' || $decline->file_name == 'decisionapprove0a.pdf') &&
                                            empty($email_msg_committee) &&
                                            empty($committee_email) && $decision->decision_rejectedbyuser != 1)
                                        <div style="display: flex; flex-direction: row; justify-content: space-between;">
                                            <div>
                                                <button type="button" class="apps-btn btn float-right ml-3"
                                                    onclick="document.getElementById('show_committee').style.display = 'block';">
                                                    אישור
                                                </button>
                                            </div>
                                            {{-- after committee --}}
                                            <div><!--&& empty($email_msg_committee) && empty($committee_email)-->
                                                <button type="button" class="apps-btn btn float-right ml-3"
                                                    onclick="cond_details(this, 4,{{ $application->id }},
[{'type':'select','class':'cancel_file_sel_reject','option':['--בחר--','דחייה רגילה','ביטול ההליך המכרזי','מכרז שנדחה','אי הגעה לוועדה']},{'type':'textarea','class':'cancel_file_text','it':'text','placeholder':'הערות'}], 'width: 700px;')
">
                                                    דחייה
                                                </button>
                                            </div>
                                        </div>
                                    @endif

                                    @if (
                                        !$decision->decision_2 &&
                                            !$decision->decision_3 &&
                                            !$decision->decision_3_a &&
                                            !$decision->decision_3_b &&
                                            !$decision->decision_4 &&
                                            ($decline->file_name == 'decisionapprove0.pdf' || $decline->file_name == 'decisionapprove0a.pdf') &&
                                            !empty($email_msg_committee) &&
                                            !empty($committee_email)  && $decision->decision_rejectedbyuser != 1)
                                        <div style="display: flex; flex-direction: row;">
                                            <div>
                                                <button type="button" class="apps-btn btn float-right ml-3"
                                                    onclick="cond_details(this, 3,{{ $application->id }},[{'type':'select','class':'cancel_file_sel','option':['--בחר--','מכתב כשיר 3','מכתב כשיר 2','מצריך מבדק מהימנות','מעבר שלב א','קבלת מועמד לעבודה']},{'type':'textarea','class':'cancel_file_text','it':'text','placeholder':'הערות'}], 'width: 700px;')">
                                                    אישור
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="apps-btn btn float-right ml-3"
                                                    onclick="cond_details(this, 4,{{ $application->id }},
[{'type':'select','class':'cancel_file_sel_reject','option':['--בחר--','דחייה רגילה','ביטול ההליך המכרזי','מכרז שנדחה','אי הגעה לוועדה']},{'type':'textarea','class':'cancel_file_text','it':'text','placeholder':'הערות'}], 'width: 700px;')
">
                                                    דחייה
                                                </button>
                                            </div>
                                        </div>
                                    @endif




                                    <div style="margin-bottom: 20px;margin-left: 20px;width: 130px;">
                                        @if (
                                            ($decision->decision_4 &&
                                                ($decline->file_name === 'decisionapprove1.pdf' || $decline->file_name === 'decisionreject1.pdf')) ||
                                                ($decline->file_name === 'decisionapprove2.pdf' || $decline->file_name === 'decisionreject2.pdf') ||
                                                $decline->file_name === 'decisionapprove3.pdf' ||
                                                $decline->file_name === 'decisionapprove4.pdf' ||
                                                $decline->file_name === 'decisionapprove5.pdf'  && $decision->decision_rejectedbyuser != 1)
                                            <span style="font-weight: 700">אישור/ דחיה</span>
                                        @endif
                                        @if (
                                            $decline->file_name === 'decisionapprove1.pdf' ||
                                                $decline->file_name === 'decisionapprove2.pdf' ||
                                                $decline->file_name === 'decisionapprove3.pdf' ||
                                                $decline->file_name === 'decisionapprove4.pdf' ||
                                                $decline->file_name === 'decisionapprove5.pdf')
                                            <img src="/img/allok.png" />
                                            <span class="captiogreen adminlighthdr">
                                                אושר
                                            </span>
                                            <span class="file-title" style="font-weight: 400;text-align: right">תשובה לאחר
                                                מכרז</span>
                                            <a href="{{ asset('upload/admin/' . $decline->url . '') }}" target="_blank"
                                                rel="noopener noreferrer" style="margin-bottom: 5px"
                                                title="decision.pdf">
                                                <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                                <span class="type pdf"></span>
                                            </a>
                                        @endif
                                        @if (
                                            $decline->file_name === 'decisionreject1.pdf' ||
                                                $decline->file_name === 'decisionreject2.pdf' ||
                                                $decline->file_name === 'decisionreject0a.pdf')
                                            <img src="/img/nok.png" />
                                            <span class="captiored">
                                                נדחה
                                            </span>
                                            <span class="file-title" style="font-weight: 400;text-align: right">דחיית מנהל
                                                אגף</span>
                                            <a href="{{ asset('upload/admin/' . $decline->url . '') }}" target="_blank"
                                                rel="noopener noreferrer" style="margin-bottom: 5px"
                                                title="decision.pdf">
                                                <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                                <span class="type pdf"></span>
                                            </a>
                                        @endif
                                        @if (
                                            !$decision->decision_5 &&
                                                ($decline->file_name === 'decisionapprove1.pdf' ||
                                                    $decline->file_name === 'decisionapprove2.pdf' ||
                                                    $decline->file_name === 'decisionapprove3.pdf' ||
                                                    $decline->file_name === 'decisionapprove4.pdf' ||
                                                    $decline->file_name === 'decisionapprove5.pdf') &&
                                                empty($gotit_email))
                                            @if (isset($email_msg_gotit))
                                                <div style="color: green;text-align: right;">{{ $email_msg_gotit }}</div>
                                            @endif
                                            @if ($application->status=='Rejected')
                                            <div style="font-weight: 700; ">זימון לאחר זכיה במכרז</div>
                                            <div>
                                                <label class="checkbox">
                                                    <input type="checkbox" name="gotit" value="זימון לאחר זכיה במכרז"
                                                        id="gotit_yes">
                                                    <span class="virtual"></span>
                                                    <span style="font-weight: 500;">זימון לאחר זכיה במכרז</span>
                                                </label>
                                            </div>
                                            @endif
                                            <div data-show_type="gotit_yes" style="display: none;">
                                                <div class="summons-user">
                                                    <div class="input-control">
                                                        <label>
                                                            <input type="text" name="gotit_date"
                                                                placeholder="הזן תאריך" style="font-size: 12px;">
                                                        </label>
                                                    </div>
                                                    <div class="input-control">
                                                        <label>
                                                            <input type="text" name="gotit_time" placeholder="הזן שעה"
                                                                style="font-size: 12px;">
                                                        </label>
                                                    </div>

                                                    <div class="input-control">
                                                        <label>
                                                            <input type="text" name="gotit_place"
                                                                placeholder="הזן מיקום" style="font-size: 12px;">
                                                        </label>

                                                    </div>
                                                    <div class="input-control">
                                                        <label>
                                                            <textarea class="detail cancel_file_text" name="gotit_msg" id="gotit_msg" placeholder="הזן הערה"
                                                                style="font-size: 12px;" row="4"></textarea>
                                                            <button style="float: right;" type="button"
                                                                class="apps-btn btn ml-3"
                                                                onclick="send_email('gotit',{{ $application->id }}, {{ $p5 }})">
                                                                שלח זימון
                                                            </button>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            @if ($decision->status!='Accepted' && $decision->decision_rejectedbyuser != 1 )    
                                            <div>
                                                {{-- <button type="button" class="apps-btn btn float-right ml-3"
                                                    onclick="cond_details(this, 5,{{ $application->id }},
			[{'type':'select','class':'cancel_file_sel_reject','option':['--בחר--','מכתב קבלת מועמד לעבודה לאחר ועדת בחינה','מכתב קבלת מועמד לעבודה לאחר ועדת בחינה- מצריך מבדק מהימנות','מכתב קבלת מועמד לעבודה לאחר ועדת בחינה- מעבר שלב א','מכתב כשיר 2','מכתב כשיר 3','מכתב דחיית מועמד לאחר ועדת בחינה','ביטול ההליך המכרזי','פרסום נוסף של המכרז']},
			{'type':'textarea','class':'cancel_file_text','it':'text','placeholder':'הערות'}], 'width: 700px;')">
                                                    שליחת תשובה לאחר הפסד/ זכייה במכרז
                                                </button> --}}
                                            </div>
                                            @endif
                                        @elseif($decision->decision_5)
                                            @if (
                                                $decline->file_name === 'decisionapprove1.pdf' ||
                                                    $decline->file_name === 'decisionapprove2.pdf' ||
                                                    $decline->file_name === 'decisionapprove3.pdf')
                                                <img src="/img/allok.png" />
                                                <span class="captiogreen adminlighthdr">
                                                    אושר
                                                </span>
                                                <span class="file-title" style="font-weight: 400;text-align: right">אישור
                                                    מנהל אגף</span>
                                                <a href="{{ asset('upload/admin/' . $decline->url . '') }}"
                                                    target="_blank" rel="noopener noreferrer" style="margin-bottom: 5px"
                                                    title="decision.pdf">
                                                    <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                                    <span class="type pdf"></span>
                                                </a>
                                            @endif
                                            @if ($decline->file_name === 'decisionreject0d.pdf')
                                                <img src="/img/nok.png" />
                                                <span class="captiored">
                                                    נדחה
                                                </span>
                                                <span class="file-title" style="font-weight: 400;text-align: right">דחיית
                                                    מנהל אגף</span>
                                                <a href="{{ asset('upload/admin/' . $decline->url . '') }}"
                                                    target="_blank" rel="noopener noreferrer" style="margin-bottom: 5px"
                                                    title="decision.pdf">
                                                    <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                                    <span class="type pdf"></span>
                                                </a>
                                            @endif
                                        @endif

                                    </div>
                                @endforeach
                                @if (!empty($email_msg_gotit) && !empty($gotit_email))
                                    <div style="color: green;text-align: right;">{{ $email_msg_gotit }}</div>
                                    <div class="mt-3 mb-2" style="overflow: hidden;padding-bottom: 10px"
                                        id="buttons-content">
                                        <h3 class="title" style="margin-bottom: 5px;">זימון לאחר זכיה במכרז</h3>
                                        <div class="file-content">
                                            <a href="{{ asset('upload/admin/' . $gotit_email) }}" target="_blank"
                                                rel="noopener noreferrer" style="margin-bottom: 5px">
                                                <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                            </a>
                                            <span class="doc-filename">Answer.pdf</span>
                                        </div>
                                    </div>
                                @endif
                            @endif
                            
                            @if ($decfile)
                    <div style="display:flex;flex-direction: column" id="ifdecfile">
                        @foreach ($decfile as $decline)
                            <div style="margin-bottom: 20px;margin-left: 20px;width: 135px;">
                                
                                @php
                                    $decision_arr = (array) $decision;
                                @endphp
                                @if (($decline->file_name === 'decisionreject0b.pdf' && $decision_arr['2nd_invitation_rejected']))
                                    <img src="/img/nok.png" />
                                    <span class="captiored">
                                        נדחה
                                    </span>
                                    <span class="" style="font-weight: 400;text-align: right">הסרת מועמדות</span>
                                    <a href="{{ asset('upload/admin/' . $decline->url . '') }}" target="_blank"
                                        rel="noopener noreferrer" style="margin-bottom: 5px" title="decision.pdf">
                                        <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                        <span class="type pdf"></span>
                                    </a>
                                @elseif($decline->file_name === 'decisionreject0_fd.pdf' || $decline->file_name === 'decisionreject0_fr.pdf')
                                <img src="/img/nok.png" />
                                    <span class="captiored">
                                        נדחה
                                    </span>
                                    {{-- <span class="file-title" style="font-weight: 400;text-align: right">אישור/ דחייה תנא
                                        סף</span> --}}
                                    <a href="{{ asset('upload/admin/' . $decline->url . '') }}" target="_blank"
                                        rel="noopener noreferrer" style="margin-bottom: 5px" title="decision.pdf">
                                        <img class="file-icon" src="{{ asset('img/file.jpg') }}">
                                        <span class="type pdf"></span>
                                    </a>
                                @endif

                            </div>
                        @endforeach
                    </div>
                    @endif



                        </div>

                @endif
            </div>
            <div class="row w-100">
                <div class="col-2 mr-auto" id="send_custom_mail_wrap">
                    <label for=""><b>הוסף מייל שתרצה לשלוח אליו את כל קבצי המועמד</b></label>
                    <input type="email" name="send_custom_mail" class="form-control" id="send_custom_mail">
                    <input hidden type="number" name="app_id" id="send_custom_mail_app_id" value="{{ $application->id }}">
                    <button class="btn btn-sm btn-info" id="send_custom_mail_btn">לחץ כאן לשליחה</button>
                </div>
            </div>
            <div style="margin-bottom: 50px;">

                <a href="/admin/tenders/{{ $application->id }}/file-download" class="btn float-left"
                    onclick="">הורדת כלל המסמכים למחשב</a>
                <button class="btn float-left" onclick="approve_file_tk(this,0 )" style="margin-left: 8px;">אישור כל
                    הקבצים
                </button>
            </div>
        </main>
    </div>
    <script>
        $(document).ready(function() {
            syncDateTimePicker();

            $('input[name="committee_date"]').datetimepicker({
                //   timepicker:false,
                format: 'd m, Y',
                mask: true,
                timepicker:false,
                minDate: "{{ now()->format('d F, Y') }}",
                
            });

            $('input[name="committee_time"]').datetimepicker({
                //   timepicker:false,
                datepicker:false,
                mask: true,
                format:'H:i'

            });

        });
        $(document).on('click', '.input-copy-btn', function(event) {
            event.preventDefault();
            /* Act on the event */
            var type = $(this).data('type')

            var clonedEle = $(`#test_info_block .input-group.${type}.first`).clone().removeClass('first').val('');

            $(`.${type}_extra_wrapper`).append(clonedEle)
            syncDateTimePicker();
        });

        $(document).on('click', '#send_custom_mail_btn', function(event) {
            event.preventDefault();
            /* Act on the event */
            var id = $('#send_custom_mail_wrap').find('#send_custom_mail_app_id').val()
            var mail = $('#send_custom_mail_wrap').find('#send_custom_mail').val()
            $('#send_custom_mail_btn').text('Sending...')
            $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '{{ route('customMailFileSend', ['did' => $application->id]) }}',
                    type: 'POST',
                    data: {
                        id: id,
                        email: mail
                    },
                })
                .done(function() {
                    console.log("success");
                    $('#send_custom_mail_btn').text('Files Sent')
                    $('#send_custom_mail_wrap').find('#send_custom_mail').val('')
                    setTimeout(() => {
                        $('#send_custom_mail_btn').text('נשלח מייל')
                    }, 5000);
                })
                .fail(function() {
                    console.log("error");
                })
                .always(function() {
                    console.log("complete");
                });


        });

        $(document).on('click', '.input-delete-btn', function(event) {
            event.preventDefault();
            /* Act on the event */
            $(this).parents('.input-group').not('.first').remove()
            syncDateTimePicker();
        });

        function syncDateTimePicker() {
            // $('#test_info_block input[name="test_time[]"]').datetimepicker({
            //   datepicker:false,
            //   format: 'H:m',
            //   mask:true,
            // });
            $('#test_info_block input[name="test_date[]"]').datetimepicker({
                //   timepicker:false,
                formatDate: 'd M, Y, H:m',
                mask: true,
                minDate: "{{ now()->format('Y/m/d') }}",
                onSelectDate: function(a, b) {
                    // console.log(a,b)
                }
            });

        }
    </script>
@endsection
