<html lang="he">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title> מחלקת חינוך, נוער וספורט  </title>
        <link href="https://fonts.googleapis.com/earlyaccess/opensanshebrew.css" rel="stylesheet">
        <style type="text/css">
            #app{
                direction: rtl;
                margin: auto;
                box-sizing: border-box;
                margin: auto;
                font-size: 20px;
                padding: 20px 30px;
                position: relative;
            }
            div#app p {
                margin: 15px 0;
            }
            footer{
              text-align: left;
              margin-top: 250px
            }
            .underline{
              min-width: 80px;
              display: inline-block;
              border-bottom: 1px solid #111;
            }
        </style>
    </head>
  <body id="bod">
    <div id="app" style="direction: rtl;">
      empty
    </div>
  </body>

</html>