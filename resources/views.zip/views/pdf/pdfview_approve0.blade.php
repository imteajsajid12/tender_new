@include('pdf.pdf_decision_header')

<div style="text-align: right;font-size:20px;letter-spacing: 0px;">
	<div>
		אנו מודים לך על הגשת מועמדותך למכרז מס' {{$tenderval}} בביתר עילית.<br>
	לצורך תאום ציפיות שכר, אנו רוצים להבהיר כי השכר המוצע לתפקיד הנוכחי הינו {{$desired_hourly_rate_value}}.<br>
		במידה והשכר המוצע לתפקיד הנ"ל תואם את ציפיותיך, נא לחץ
		<a target="_blank" href="https://tbetar.automas.co.il/approve/<?php echo $decId; ?>">כאן</a>, לטובת המשך התהליך.<br>
		במידה והשכר המוצע לתפקיד הנ"ל אינו תואם את ציפיותיך, להסרת מועמדות, יש ללחוץ
		<a target="_blank" href="https://tbetar.automas.co.il/cancel/<?php echo $decId; ?>">כאן.</a>
	</div>

	@if(isset($decision_1) && !empty($decision_1) && strlen($decision_1) > 0)
		<p>הערות:<br> {{$decision_1}} </p>
	@endif
	@if(isset($users) && !empty($users))
	<div style="margin-top: 50px;font-weight: normal;">
		<p style="line-height: 40px">העתקים: <br> {!! $users !!} </p>
	</div>
	@endif
</div>
<br><br><br>
<br>
<style>
.signature {
				margin-top: 150px;
				margin-bottom: 50px;
                font-size: 20px;
                height: 100px;
                width: 100%;
                text-align: left;
				display: flex;
				flex-direction: column;
            }
        </style>

	<div class="signature">
		{{-- <img width="150" src="{{ asset('/img/signature.jpg') }}" alt=""> --}}
		<div>
			<a href="https://www.betar-illit.muni.il/">www.betar-illit.muni.il</a>
		</div>
		<div>
			<img src="{{ asset($app_dec?->tender_body_image ?? '/img/logo-b.png') }}">
		</div>
    </div>

@include('pdf.pdf_decision_footer')
