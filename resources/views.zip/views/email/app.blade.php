
<html>
	<body dir="rtl" style="font-family: Arial, Helvetica, sans-serif; font-size: 20px; color: #5d5c5c;">
		<div style="width: 100%; text-align: center;">
			<?php echo $body ; ?>
			
		</div>
		   <div style="width: 100%;text-align: center;">
		מחלקת גיוס<br>
אגף משאבי אנוש<br>
			<!--<a href="http://www.ramle.muni.il">www.ramle.muni.il</a><br>-->
			{{-- <img src="{{asset('/img/sin-img.jpg')}}"><br> --}}
		
    </div>
	</body>
</html>
