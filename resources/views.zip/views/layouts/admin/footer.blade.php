	<footer class="apps-cart-footer container_s">
		<div class="row">
	        <!--<div class="sky-rtl col-md-6">
	            <img src="{{ asset('img/footer-menu-v2.png') }}" style="padding-left: 10px;margin-left: 6px;margin-top: -15px">
	        </div>-->
	        <div class="col-md-6">
	            אוטומס ©  כל הזכויות שמורות
	        </div>
		</div>
    </footer>
    <div id="fader"><img src="{{ asset('img/loader.gif') }}"></div>
	<script src="{{asset('js/main.js')}}"></script>
    <link href="{{asset('css/daterangepicker.css')}}" rel="stylesheet">
    <script src="{{asset('js/datetimepicker.js')}}"></script>

</body>
</html>
