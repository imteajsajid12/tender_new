@extends('forms.layouts.header3')
@section('content')
    <?php
    $tenderid = 0;
    if (strpos($_SERVER['QUERY_STRING'], 'tenderid') >= 0) {
        $line0 = substr($_SERVER['QUERY_STRING'], strpos($_SERVER['QUERY_STRING'], 'tenderid') + 9);
        if (!strpos($line0, '&')) {
            $tenderid = $line0;
        } else {
            $tenderid = substr($line0, 0, strpos($line0, '&'));
        }
    }
    if (isset($_GET['file']) && $_GET['file'] != '') {
        $file = $_GET['file'];
    }
    $tenderdisplay = $_GET['tenderdisplay'];
    
    // function char_at($str, $pos)
    // {
    // 	return $str[$pos];
    // }
    $textChange = 'מכרז';
    if ($tender->tender_type != 0) {
        $textChange = 'משרה';
    }
    ?>

    @if ($tender->stopped == 1 || $tender->outofdate == 1)
        <h1 style="color:Red">
            המכרז אינו פעיל
        </h1>
    @endif
    <!--
        <script language="JavaScript">
            var csrfTag = document.createElement('meta');
            csrfTag.name = "csrf-token";
            csrfTag.content = "{{ csrf_token() }}";
            document.getElementsByTagName('head')[0].appendChild(csrfTag);
        </script>
        -->
    <script>
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').prop('title', 'סוגי מסמכים מותרים הם: pdf עד 20 mb');
        });
    </script>
    <form id="form" method="post" action="/page5/create" enctype="multipart/form-data">
        @if (isset($file))
            <div style="text-align: left;margin-bottom: 20px;">
                <a target="_blank" href="{{ asset('upload/admin/' . $file) }}" download style="margin-bottom: 5px">
                    הורדת קובץ צירוף תכולת מכרז
                </a>
            </div>
        @endif
        <div class="header_line faind_line">
            <!--@if ($tender->tender_type != 2)
    פרטי מכרז
@else
    פרטי משרה
    @endif-->
            פרטי {{ $textChange }}
        </div>
        @if ($tender->is_test_required)
            <div class="alert alert-info alert-link">מבחן חובה במשרה זו</div>
        @endif
        <div class="faind_line fullwidth">
            @if ($tender->tender_type != 1 && $tender->tender_type != 2)
                <div class="input-control">
                    <label>
                        <span class="caption captiobblue" style="font-weight: bold;">{{ $textChange }}</span><br>
                        @if ($tender->ttype == 1)    
                        <label class="radio">
                            <input type="radio" name="tender_type" disabled {{ $tender->ttype == 1 ? 'checked' : '' }}
                                value="yes" required="true" id="tender_type_yes">
                            <span class="virtual"></span>
                            <span class="caption"> {{ $textChange }} פנימי</span>
                        </label>
                        @else    
                        <label class="radio">
                            <input type="radio" name="tender_type" disabled {{ $tender->ttype == 2 ? 'checked' : '' }}
                                value="no" required="true">
                            <span class="virtual"></span>
                            <span class="caption"> {{ $textChange }} חיצוני</span>
                        </label>
                        @endif
                    </label>
                </div>
            @endif
            @if ($tender->tender_type != 1 && $tender->tender_type != 2)
                <div style="display:flex;">
                    <div>
                        תאריך התחלת {{ $textChange }}: {{ date('d-m-Y H:i', strtotime($tender->start_date)) }}
                        &nbsp;&nbsp;
                    </div>
                    <div>
                        תאריך סיום {{ $textChange }}: {{ date('d-m-Y H:i', strtotime($tender->finish_date)) }}
                        &nbsp;&nbsp;
                    </div>
                </div>
            @endif
        </div>
        <div class="faind_line fullwidth">

            <div class="input-control fg2">
                <label>
                    <!--@if ($tender->tender_type != 2)
    <span class="caption captiobblue"> מספר מכרז כפי שמופיע במסמכי המכרז:</span>
@else
    <span class="caption captiobblue"> מספר משרה כפי שמופיע במסמכי המכרז:</span>
    @endif-->
                    <span class="caption captiobblue"> מספר {{ $textChange }} כפי שמופיע במסמכי
                        ה{{ $textChange }}:</span>
                </label>
                <input type="hidden" name="tenderid" value="<?php echo $tenderid; ?>" />
                <div class="captionline"
                    style="margin-top:5px;padding-top:20px;margin-left:20px;padding-bottom:20px;text-align: center">
                    {{ $tenderdisplay != '' ? $tenderdisplay : $tenderid }}
                </div>
            </div>
            <div class="input-control fg2">
                <label>
                    <span class="caption captiobblue">*  אגף/מחלקה</span>
                </label>
                <input type="hidden" name="brunch" value="<?php echo $tender->brunch; ?>" />
                <div class="captionline" style="margin-top:5px;padding-top:20px;padding-bottom:20px;text-align: center">
                    {{ $tender->brunch }}
                </div>
            </div>
            {{-- <div class="input-control fg2">
                <label>
                    <span class="caption captiobblue">*  רמה תפקודית</span>
                </label>
                <input type="hidden" name="tname" value="<?php echo $tender->tname; ?>" />
                <input type="hidden" name="tender_id" value="<?php echo $tender->id; ?>" />
                <div class="captionline" style="margin-top:5px;padding-top:20px;padding-bottom:20px;text-align: center">
                    {{ collect($tender->functional_level)->join(', ',' and ') }}
                </div>
            </div> --}}
            <div class="input-control fg2">
                <label>
                    <span class="caption captiobblue">*  מועמד/ת לתפקיד</span>
                </label>
                <input type="hidden" name="tname" value="<?php echo $tname; ?>" />
                <div class="captionline" style="margin-top:5px;padding-top:20px;padding-bottom:20px;text-align: center">
                    {{ $tname }}
                </div>
            </div>
        </div>
        <div class="faind_line fullwidth">

            <div class="input-control fg2">
                <label><span class="caption captiobblue">מנהל 	 </span></label>
                <div class="captionline"
                    style="margin-top:5px;padding-top:20px;margin-left:20px;padding-bottom:20px;text-align: center">
                    {{ $tender->input_manager }}
                </div>
            </div>

            <div class="input-control fg2">
                <label><span class="caption captiobblue">היקף </span></label>
                <div class="captionline"
                    style="margin-top:5px;padding-top:20px;margin-left:20px;padding-bottom:20px;text-align: center">
                    {{ $tender->job_scope }}
                </div>
            </div>

            <div class="input-control fg2">
                <label><span class="caption captiobblue">כפיפות</span></label>
                <div class="captionline"
                    style="margin-top:5px;padding-top:20px;margin-left:20px;padding-bottom:20px;text-align: center">
                    {{ $tender->subordinations }}
                </div>
            </div>

            <div class="input-control fg2">
                <label><span class="caption captiobblue">מתח	דרגות</span></label>
                <div class="captionline"
                    style="margin-top:5px;padding-top:20px;margin-left:20px;padding-bottom:20px;text-align: center">
                    {{ $tender->grades_voltage }}
                </div>
            </div>
            
        </div>
        <div class="faind_line fullwidth">
            @if ($tender->ttype == 1)
                <div class="text">
                    בהתאם להוראות משרד הפנים ל{{ $textChange }} פנימי רשאי לגשת עובד קבוע המועסק ברשות מעל שנתיים.<br>
                    יובהר כי עובד המועסק במשרה זמנית ועובד המועסק על בסיס שכר שעתי אינם רשאים להתמודד ב{{ $textChange }}
                    פנימי.<br>
                    כמו כן עובד שתפקידו אינו מזכה אותו בקביעות אינו זכאי לגשת ל{{ $textChange }} פנימי.
                </div>
            @endif
        </div>

        @if (count($conditions) > 0)
            <div class="header_line faind_line">
                תנאי סף </div>
        @endif
        <div class="faind_line">
            @if (count($conditions) > 0)
                <div class="input-control" style="width:100%">
                    <?php
                    $y = count($form_file) - 2; // 52;
                    $x = 3;
                    $isHeader1 = false;
                    $isHeader2 = false;
                    $isHeader3 = false;
                    $isHeader4 = false;
                    ?>

                    <div style="overflow-x:auto;">
                        <table style="border:0;">
                            <?php $sum = 0; ?>
                            @foreach ($conditions as $k => $condition)
                                <?php
                                if (strpos($condition, '=>') !== false) {
                                    $header = explode('=>', $condition);
                                    //var_dump($header[1]);
                                }
                                if (strpos($condition, '=>') !== false) {
                                    $con = explode('=>', $condition);
                                    //var_dump($con[0]);
                                    $required = $con[1];
                                    if ($required === 'not_required') {
                                        $required_val = '';
                                    } else {
                                        $required_val = 'required';
                                    }
                                } else {
                                    $required_val = 'required';
                                    $con[0] = '';
                                }
                                $index_open = strpos($condition, '[');
                                $index = $condition[$index_open + 1];
                                //var_dump($index_open);
                                if (is_numeric($index)) {
                                    $key = $index + $x;
                                    if (strpos($con[0], $form_file[$key]['title']) !== false) {
                                        $file = $form_file[$key];
                                    }
                                } else {
                                    ++$y;
                                    $file = ['name' => 'tender_add_cond[' . $y . ']', 'title' => $condition, 'show_type' => '', 'required' => ''];
                                    $key = $y;
                                }
                                ?>
                                @if (!$isHeader1 && isset($header[1]) && $header[1] === 'השכלה ודרישות מקצועיות')
                                    <tr>
                                        <td class="caption captiobblue" style="font-weight: bold;border:0;">
                                            {{ $header[1] }}</td>
                                    </tr>
                                    <?php $isHeader1 = true; ?>
                                @endif
                                @if (!$isHeader2 && isset($header[1]) && $header[1] === 'קורסים והכשרות מקצועיות')
                                    <tr>
                                        <td class="caption captiobblue" style="font-weight: bold;border:0;">
                                            {{ $header[1] }}</td>
                                    </tr>
                                    <?php $isHeader2 = true; ?>
                                @endif
                                @if (!$isHeader3 && isset($header[1]) && $header[1] === 'ניסיון מקצועי')
                                    <tr>
                                        <td class="caption captiobblue" style="font-weight: bold;border:0;">
                                            {{ $header[1] }}</td>
                                    </tr>
                                    <?php $isHeader3 = true; ?>
                                @endif
                                @if (!$isHeader4 && isset($header[1]) && $header[1] === 'דרישות נוספות')
                                    <tr>
                                        <td class="caption captiobblue" style="font-weight: bold;border:0;">
                                            {{ $header[1] }}</td>
                                    </tr>
                                    <?php $isHeader4 = true; ?>
                                @endif
                                <?php $sum = $sum + 100; ?>

                                @if ((strpos($condition, '=>required') !== false || strpos($condition, '=>not_required') !== false) && isset($key))
                                    <tr id="{{ $key }}">
                                        <td style="border: 0;text-align: right;">
                                            <div style="color:black">{{ $con[0] }}<span style="margin-right: 5px;"
                                                    data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>
                                        </td>
                                        <td style="border:0;" class="file-block">

                                            <?php $ind = $key + $sum; ?>
                                            <input type="hidden" name="vals" class="formvalsfile"
                                                value="{{ $ind }}" />
                                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                value="{{ $ind }}" />
                                            <?php for($z=0; $z<10; $z++,$ind++){
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		$required_val="";
	}
								
							
       
        ?>
                                            <div id="add_file_line_{{ $ind }}" class="add_file_line"
                                                {{ $style }}>
                                                <div style="display:flex;flex-direction:row;">
                                                    <div>
                                                        <div class="upload-block">

                                                            <a href="#" id="rcfile-upload-{{ $ind }}"
                                                                class="rm" style="display:none"
                                                                onclick="removeFile(this,{{ $ind }});return false;"><i
                                                                    class="trash-icon"></i></a>
                                                            <input id="{{ $ind }}" type="text" disabled
                                                                class="btn-input-upload data-val"
                                                                value="אנא צרף תעודה רלוונטית"
                                                                data-key="{{ $ind }}"
                                                                data-cond="{{ $con[0] }}"
                                                                data-val="{{ $required_val }}" />
                                                            <label for="cfile-upload-{{ $ind }}"
                                                                class="btn-upload">
                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                    xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                    width="19px" height="13px"
                                                                    style="transform: scale(0.8)  translateY(4px);">
                                                                    <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                        d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                                </svg>

                                                                <span style="margin-top:-2px">

                                                                    בחר קובץ
                                                                </span>
                                                            </label>

                                                            <input id="cfile-upload-{{ $ind }}" type="file"
                                                                name="file[{{ $ind }}]"
                                                                onchange="fileChange(this);" accept="application/pdf"
                                                                {{ $required_val }} />

                                                        </div>

                                                    </div>
                                                    <div class="aline">
                                                        <button type="button" class="addbutton"
                                                            onclick="showLineFile(this)"
                                                            style="width:30px; height:30px; padding:0;">
                                                            <img src="/img/icons/plus.png" />

                                                        </button>
                                                    </div>

                                                    <?php if($z ==0){?>
                                                    @if ($required_val === 'required')
                                                        <div style="color:red; font-size: 10px; margin-right: 3px;">תנאי סף
                                                            מסמך חובה לצירוף</div>
                                                    @else
                                                        <div style="color:green; font-size: 10px; margin-right: 3px;">יתרון
                                                            מסמך לא חובה לצירוף</div>
                                                    @endif
                                                    <?php } ?>

                                                </div>
                                            </div>
                                            <?php
	    
} ?>
                                        </td>
                                    </tr>
                                @elseif(strpos($condition, '=>cond_or') !== false)
                                    <?php
                                    if (strpos($condition, '=>cond_or') !== false) {
                                        $cond_or = explode('=>cond_or', $condition);
                                        //var_dump($cond_or[0]);
                                    } else {
                                        $cond_or[0] = '';
                                    }
                                    $y++;
                                    $key = $y;
                                    //echo $key;
                                    $file = ['name' => 'tender_cond_or[' . $key . ']', 'title' => $condition, 'show_type' => '', 'required' => ''];
                                    ?>
                                    <tr id="{{ $key }}">
                                        <td style="border: 0;text-align: right;">
                                            <div style="color:black"><b>או</b> {{ $cond_or[0] }}<span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                                        </td>
                                        <td style="border:0" class="file-block">
                                            <?php $ind = $key + $sum; ?>
                                            <input type="hidden" name="vals" class="formvalsfile"
                                                value="{{ $ind }}" />
                                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                value="{{ $ind }}" />
                                            <?php for($z=0; $z<10; $z++,$ind++){
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		$required_val="";
	}
								
							
       
        ?>
                                            <div id="add_file_line_{{ $ind }}" class="add_file_line"
                                                {{ $style }}>
                                                <div style="display:flex;flex-direction:row;">
                                                    <div>
                                                        <div class="upload-block">

                                                            <a href="#" id="rcfile-upload-{{ $key }}"
                                                                class="rm" style="display:none"
                                                                onclick="removeFile(this,{{ $key }});return false;"><i
                                                                    class="trash-icon"></i></a>
                                                            <input id="{{ $key }}" type="text" disabled
                                                                class="btn-input-upload condition-or"
                                                                value="אנא צרף תעודה רלוונטית"
                                                                data-key="{{ $key }}"
                                                                data-cond="{{ $cond_or[0] }}" />
                                                            <label for="cfile-upload-{{ $key }}"
                                                                class="btn-upload">
                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                    xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                    width="19px" height="13px"
                                                                    style="transform: scale(0.8)  translateY(4px);">
                                                                    <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                        d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                                </svg>

                                                                <span style="margin-top:-2px">

                                                                    בחר קובץ
                                                                </span>
                                                            </label>

                                                            <input id="cfile-upload-{{ $key }}" type="file"
                                                                name="file[{{ $key }}]"
                                                                onchange="fileChange(this);"
                                                                accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"
                                                                required data-val="condition-or" />


                                                        </div>
                                                    </div>
                                                    <div class="aline">
                                                        <button type="button" class="addbutton"
                                                            onclick="showLineFile(this)"
                                                            style="width:30px; height:30px; padding:0;">
                                                            <img src="/img/icons/plus.png" />

                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                @elseif(strpos($condition, '=>confirm') !== false)
                                    <?php
                                    if (strpos($condition, '=>confirm') !== false) {
                                        $confirm = explode('=>confirm', $condition);
                                        //var_dump($cond_or[0]);
                                    } else {
                                        $confirm[0] = '';
                                    }
                                    ?>
                                    <tr>
                                        <td style="border: 0;text-align: right;">
                                            <div style="color:black">{{ $confirm[0] }}<span
                                                    style="margin-right: 5px;"></span></div>
                                            <input type="checkbox" name="{{ $confirm[0] }}" class=""
                                                style="transform: translateY(8px);margin-left:3px;" value="1"
                                                required />
                                            <label>
                                                מאשר/ת שהנני עומד/ת בדרישות אלה
                                            </label>
                                        </td>
                                        <td style="border:0; text-align: right;">

                                        </td>
                                @endif
                            @endforeach
                        </table>

                        @foreach ($conditions as $condition)
                            @if (strpos($condition, '=>') === false)
                                <div style="color:black">{{ $condition }}</div>
                                <span class="caption captiobblue" style="font-weight: bold;">פירוט</span>
                                <textarea class="detail" name="condition_text" {{ $required_val }}></textarea>
                            @endif
                        @endforeach
                    </div><br />
                    <span>

                        <input type="checkbox" name="conditions_ok" class=""
                            style="transform: translateY(8px);margin-left:3px;" value="1" id="conditions_ok"
                            required>
                        <label>
                            הנני מאשר כי אני עומד בכל התנאי סף
                        </label>
                    </span>
                </div>
            @endif

            <div class="header_line faind_line">
                פרטים אישיים
            </div>
            <div class="faind_line "
                style="display:flex; flex-direction: row; flex-wrap:wrap; justify-content: space-between">
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* שם פרטי</div>
                        <input type="text" name="firstname" required="" class="mmax-440" placeholder="">
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* שם משפחה</div>
                        <input type="text" name="lastname" required="" class="mmax-440" placeholder="">
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* מספר ת.ז</div>
                        <input type="text" name="id_tz" required="" minlength="9" maxlength="9"
                            pattern="^[0-9]+$" class="mmax-440 id_number" placeholder="">
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* כתובת דוא"ל</div>
                        <input placeholder="username@domainname.co.il" type="email" name="email" required=""
                            class="mmax-440">
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* מספר טלפון נייד</div>
                        <input type="text" name="personal_phone" pattern="^[0-9]+$" minlength="7" maxlength="7"
                            class="mmax-280" placeholder="" required="">
                        <select class="max-65 phn" name="personal_phone_select">
                            <option value="050">050</option>
                            <option value="052"> 052</option>
                            <option value="053"> 053</option>
                            <option value="054"> 054</option>
                            <option value="055"> 055</option>
                            <option value="057"> 057</option>
                            <option value="058"> 058</option>
                        </select>
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <label>
                        <span class="caption captiobblue" style="font-weight: bold;">* מין</span><br>
                        <label class="radio">
                            <input type="radio" name="gender" value="male" required="true">
                            <span class="virtual"></span>
                            <span class="caption">זכר</span>
                        </label>
                        <label class="radio">
                            <input type="radio" name="gender" value="female" required="true">
                            <span class="virtual"></span>
                            <span class="caption">נקבה</span>
                        </label>
                    </label>
                </div>
                <hr>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* עיר מגורים</div>
                        <input type="text" name="personal_city" required="" class="mmax-440" placeholder="">
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* רחוב</div>
                        <input type="text" name="personal_street" required="true" class="mmax-440" placeholder="">
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* מספר בית</div>
                        <input type="text" name="personal_house" required="" pattern="^[0-9]+$" class="mmax-440"
                            placeholder="">
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">* מספר דירה</div>
                        <input type="text" name="personal_flat" required="" pattern="^[0-9]+$" class="mmax-440"
                            placeholder="">
                    </div>
                </div>
                <div class="input-control inline fg2">
                    <div>
                        <div class="caption bold max-w300">מיקוד</div>
                        <input type="text" name="personal_zipcode" pattern="^[0-9]+$" class="mmax-440"
                            placeholder="">
                    </div>
                </div>
            </div>
            <div class="faind_line">
                <div class="input-control inline fg2">
                    <label></label>
                    <label>
                        <span class="caption" style="font-weight: bold;"> כתובת למשלוח דואר</span><br>
                        <label class="radio">
                            <input onchange="showchangepostaladdress()" type="radio" checked
                                name="personal_postal_address" value="yes" required=""
                                id="personal_postal_address_yes">
                            <span class="virtual"></span>
                            <span class="scaption">כתובת למשלוח דואר זהה לכתובת המגורים</span>
                        </label>
                        <label class="radio">
                            <input type="radio" onchange="showchangepostaladdress()" name="personal_postal_address"
                                value="no" required="" id="personal_postal_address_no">
                            <span class="virtual"></span>
                            <span class="scaption">כתובת למשלוח דואר שונה מכתובת המגורים</span>
                        </label>
                    </label>
                    <div id="postalblock" data-show_type="personal_postal_address_no"><input id="postalinout"
                            type="text" name="postal" placeholder="אנא הזן את הכתובת המלאה למשלוח דואר" /></div>
                </div>
            </div>
            <div>
                {{-- <div class="header_line faind_line">
                    ניסיון תעסוקתי רלוונטי
                </div>
                @if ($tender->job_details)
                    @foreach (($tender->job_details) as $item)
                        {{ config('static_array.jobDetails')[$item] }},
                    @endforeach.
                @endif --}}
                {{-- <div class="text">
                    ניסיון מקצועי: אישורי העסקה הכוללים בין היתר תקופת העבודה, היקף המשרה, ותיאור תמציתי של תוכן התפקיד.
                    במקרים חריגים בהם אין בידי המועמד אפשרות להציג אישור מעסיק ממעסיקים קודמים, יהיה עליו להגיש תצהיר חתום:
                    ככלל, מועמד המבקש להשתתף ב{{ $textChange }}, נדרש לצרף קורות חיים והעתקי מסמכים המעידים על השכלה
                    וניסיון כנדרש בנוסח ה{{ $textChange }} שפורסם. במקרים החריגים כדלהלן:<br>
                    א. סגירת מקום העבודה או הלימודים<br>
                    ב. בעל עסק עצמאי<br>
                    ג. שמירה על דיסקרטיות במקום העבודה הנוכחי<br>
                    ד. סירוב מקום העבודה או מוסד הלימודים להמצאת אישור העסקה או לימודים, בכפוף להמצאת אסמכתא תומכת בדבר
                    הפנייה למקום העבודה או הלימודים וסירובם להמציא את האישור הנדרש<br>
                    רשאי המועמד להגיש תצהיר חתום על ידי עו"ד ובו פירוט הנסיבות בגינן לא ניתן להציג אישור כאמור וכן פירוט
                    בדבר השכלתו ו/או ניסיונו של המועמד , וזאת בצירוף אישור המוסד לביטוח לאומי המפרט את תקופות ההעסקה.
                    <ul>
                        <li>
                            עבודה ביותר מחצי משרה תיחשב כמשרה מלאה לצורך עמידה בתנאי הסף.
                            עבודה בחצי משרה או פחות מכך, ובלבד שלא תפחת מ 25% משרה, תחושב באופן משוקלל.</li>
                        <li>
                            ניסיון במגזר הציבורי מוגדר כניסיון בתעסוקה בגופי ממשלה, רשויות מקומיות, תאגידים סטטוטוריים,
                            תאגידים עירוניים וחברות ממשלתיות.</li>
                        <li>
                            ניסיון שנרכש בשירות צבאי חובה או שירות לאומי ייחשבו כניסיון מקצועי לעניין עמידה
                            בתנאי סף, ובלבד שמדובר בניסיון מוכח ורלוונטי לביצוע התפקיד בהתאם לתחומי העיסוק המפורטים בו.</li>
                        <li>
                            לניסיון מקצועי בתחום המשפטים ייחשב הניסיון שנצבר לאחר קבלת הרישיון מלשכת
                            עורכי הדין בישראל (למען הסר ספק, תקופת ההתמחות אינה באה בחשבון מניין שנות
                            הניסיון המקצועי( עם זאת, מובהר כי תקופת עבודה כתובע צבאי, כתובע במשטרה, כנציג
                            היועץ המשפטי לממשלה המופיע בבתי משפט וכו' (אף אם במהלכה לא היה בידי המועמד רישיון לעריכת דין),
                            תיחשב לניסיון מקצועי רלוונטי, ככל שהוצגו הוכחות תומכות לכך.</li>
                        <li>
                            לניסיון מקצועי בתחום הכספים, ייחשב גם הניסיון שנצבר בתקופת ההתמחות בראיית חשבון.</li>
                    </ul>
                    <br><br>
                </div> --}}
                <div class="header_line faind_line">
                    מקומות עבודה קודמים
                </div>
                <div id="experience_block">
                    <div id="experience_line0" class="line">
                        <div class="inline">
                            <div class="input-control inline">
                                <div>
                                    <div class="caption bold max-w300">מקום עבודה</div>
                                    <input type="text" name="exp_position[]" class="max-440" placeholder="" required>
                                </div>
                            </div>
                            <div>
                                <div class="input-control inline">
                                    <div>
                                        <div class="caption bold max-w300">תאריך תחילת עבודה</div>
                                        <input type="date" name="expe_start[]" class="max-220" required>
                                    </div>
                                </div>
                                <div class="input-control inline">
                                    <div>
                                        <div class="caption bold max-w300">תאריך סיום עבודה</div>
                                        <input type="date" name="exp_finish[]" class="max-220" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="input-control inline">
                            <div>
                                <div class="caption bold max-w300">תיאור תפקיד</div>
                                <textarea type="text" name="exp_descr[]" maxlength="103" class="max-220 height-2lines" placeholder="" required></textarea>
                            </div>
                        </div>
                        <div class="input-control inline">
                            <div>
                                <div class="caption bold max-w300">הסיבה להפסקת עבודה</div>
                                <textarea type="text" name="exp_reasontocomplete[]" class="max-220 height-2lines" placeholder="" required></textarea>
                            </div>
                        </div>
                        
                        <div class="input-control inline">
                            <div>
                                <div class="caption bold max-w300">היקף משרה</div>
                                <input type="text" name="exp_scope[]" class="max-440" placeholder="" required>
                            </div>
                        </div>
                        <div class="input-control inline file-block">
                            <div class="caption max-w300">אנא צרף תעודה רלוונטית <span style="margin-right: 5px;"
                                    data-toggle="tooltip"
                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                            <?php $key = 23; ?>

                            <input type="hidden" name="vals" class="formvalsfile" value="{{ $key }}" />
                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                value="{{ $key }}" />
                            <?php for($z=0; $z<10; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
		
	}else{
		$style = "style=display:none";
		
	}
	$required_val=$file['required'];							
							
       
        ?>
                            <div id="add_file_line_{{ $key }}" class="add_file_line" {{ $style }}>
                                <div style="display:flex;flex-direction:row;">
                                    <div class="upload-block">
                                        <a href="#" id="rcfile-upload-{{ $key }}" class="rm"
                                            style="display:none"
                                            onclick="removeFile(this,{{ $key }});return false;"><i
                                                class="trash-icon"></i></a>
                                        <input id="{{ $key }}" type="text" disabled class="btn-input-upload"
                                            value="אנא צרף תעודה רלוונטית" />
                                        <label for="cfile-upload-{{ $key }}" class="btn-upload ">
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="19px" height="13px"
                                                style="transform: scale(0.8)  translateY(4px);">
                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                            </svg>
                                            <span style="margin-top:-2px">בחר קובץ</span>
                                        </label>
                                        {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword" required/> --}}
                                        <input id="cfile-upload-{{ $key }}" type="file"
                                            name="file[{{ $key }}]" onchange="fileChange(this)"
                                            accept="application/pdf" {{ $required_val }} />



                                    </div>
                                    <div class="aline">
                                        <button type="button" class="addbutton" onclick="showLineFile(this)"
                                            style="width:30px; height:30px; padding:0;">
                                            <img src="/img/icons/plus.png" />

                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>

                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="aline" style="flex-direction: row-reverse">
            <button type="button" class="addbutton leftbtn" onclick="showLine1()">
                <img src="/img/icons/plus.png" />
                הוספת מקום עבודה נוסף
            </button>
        </div>
        <input type="hidden" name="vals" id="formvals1" value="0" />
        <?php $sum1 = 0;
        $key = 55; ?>
        @for ($i = 1; $i < 9; $i++)
            <?php
            $req = $i < 1 ? 'required' : '';
            ?>
            <div id="experience_line_{{ $i }}" style="display:none;">
                <div class="inline" class="line">
                    <div class="input-control inline">
                        <div>
                            <div class="caption bold max-w300">מקום עבודה</div>
                            <input type="text" name="exp_position[]" class="max-440" placeholder=""
                                {{ $req }}>
                        </div>
                    </div>
                    <div>
                        <div class="input-control inline">
                            <div>
                                <div class="caption bold max-w300">תאריך תחילת עבודה</div>
                                <input type="date" name="expe_start[]" class="max-220" {{ $req }}>
                            </div>
                        </div>
                        <div class="input-control inline">
                            <div>
                                <div class="caption bold max-w300">תאריך סיום עבודה</div>
                                <input type="date" name="exp_finish[]" class="max-220" {{ $req }}>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="input-control inline">
                    <div>
                        <div class="caption bold max-w300">תיאור תפקיד</div>
                        <textarea type="text" name="exp_descr[]" maxlength="103" class="max-220 height-2lines" placeholder=""
                            {{ $req }}></textarea>
                    </div>
                </div>
                <div class="input-control inline">
                    <div>
                        <div class="caption bold max-w300">הסיבה להפסקת עבודה</div>
                        <textarea type="text" name="exp_reasontocomplete[]" class="max-220 height-2lines" placeholder=""
                            {{ $req }}></textarea>
                    </div>
                </div>
                <div class="input-control inline">
                    <div>
                        <div class="caption bold max-w300">היקף משרה</div>
                        <input type="text" name="exp_scope[]" class="max-440" placeholder="">
                    </div>
                </div>
                <div class="input-control inline file-block">
                    <div class="caption max-w300">אנא צרף תעודה רלוונטית <span style="margin-right: 5px;"
                            data-toggle="tooltip" title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                    <?php //$key = $sum1 + 55;
                    //$sum1= $sum1+10;
                    ?>
                    <input type="hidden" name="vals" class="formvalsfile" value="{{ $key }}" />
                    <input type="hidden" name="valsstatic" class="formvalsfilestatic" value="{{ $key }}" />

                    <?php for($z=0; $z<10; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
		
	}else{
		$style = "style=display:none";
		
	}
	$required_val=$file['required'];							
							
       
        ?>
                    <div id="add_file_line_{{ $key }}" class="add_file_line" {{ $style }}>
                        <div style="display:flex;flex-direction:row;">
                            <div class="upload-block">

                                <a href="#" id="rcfile-upload-{{ $key }}" class="rm"
                                    style="display:none" onclick="removeFile(this,{{ $key }});return false;"><i
                                        class="trash-icon"></i></a>
                                <input id="{{ $key }}" type="text" disabled class="btn-input-upload"
                                    value="אנא צרף תעודה רלוונטית" />
                                <label for="cfile-upload-{{ $key }}" class="btn-upload ">
                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                        width="19px" height="13px" style="transform: scale(0.8)  translateY(4px);">
                                        <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                            d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                    </svg>
                                    <span style="margin-top:-2px">

                                        בחר קובץ
                                    </span>
                                </label>
                                {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                <input id="cfile-upload-{{ $key }}" type="file"
                                    name="file[{{ $key }}]" onchange="fileChange(this)"
                                    accept="application/pdf" {{ $required_val }} />

                            </div>
                            <div class="aline">
                                <button type="button" class="addbutton" onclick="showLineFile(this)"
                                    style="width:30px; height:30px; padding:0;">
                                    <img src="/img/icons/plus.png" />

                                </button>
                            </div>

                        </div>
                    </div>
                    <?php } ?>
                </div>

                <div class="aline" style="flex-direction: row-reverse">
                    <a href="#" class="closebtn" style='margin-top:24px' onclick="closeLine(this)"><img
                            src="/img/close-lg.png" /></a>
                </div>
            </div>
        @endfor
        @if ($tender->has_salary)
        <div>
            <div class="header_line faind_line"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                שכר
            </font></font></div>
            <div class="input-control inline">
                
                @if($tender->salary)
                <label class="caption bold max-w300" for="salary_accept_checkbox">אני מאשר שכר זה ({{ $tender->salary }})</label>

                <label class="radio">
                    <input type="radio" value="yes" name="salary_accept" id="">
                    <span class="virtual"></span>
                    <span class="scaption">כן</span>
                </label>

                <label class="radio">
                    <input type="radio" value="no" name="salary_accept" id="">
                    <span class="virtual"></span>
                    <span class="scaption">לא</span>
                </label>
                @else
                <label class="caption bold max-w300" for="">נא הזן את ציפיות השכר שלך</label>
                <input type="number" name="salary" id="salary_input">
                @endif
           
            </div>
        </div>
        <div>
            @endif
            <div class="header_line faind_line">
                ניסיון ניהולי רלוונטי
            </div>
            <div id="expp_block">
                <div id="expp__line0">
                    <div>
                        <div class="input-control inline fg2">
                            <div>
                                <div class="caption bold max-w300">מקום עבודה</div>
                                <input type="text" name="expp_position[]" class="max-440" placeholder="">
                            </div>
                        </div>

                        <div class="input-control inline fg2">
                            <div>
                                <div class="caption bold max-w300">תפקיד</div>
                                <input type="text" name="expp_descr[]" maxlength="103" class="max-440"
                                    placeholder="">
                            </div>
                        </div>

                        <div class="input-control inline fg2">
                            <div>
                                <div class="caption bold max-w300">תאריך תחילת תקופת הניהול</div>
                                <input type="date" name="expp_pstart[]" class="max-220">
                            </div>
                        </div>
                        <div class="input-control inline fg2">
                            <div>
                                <div class="caption bold max-w300">תאריך סיום תקופת הניהול</div>
                                <input type="date" name="expp_finish[]" class="max-220">
                            </div>
                        </div>



                        <div class="input-control inline fg2">
                            <div>
                                <div class="caption bold max-w300">מספר העובדים הכפופים</div>
                                <input type="text" name="expp_employee[]" class="max-220" placeholder="">
                            </div>
                        </div>
                        <div class="input-control inline fg2">
                            <div>
                                <div class="caption bold max-w300">דרגה</div>
                                <input type="text" name="expp_level[]" class="max-150" placeholder="">
                            </div>
                        </div>



                        <div class="input-control inline file-block">
                            <div class="caption max-w300">אנא צרף תעודה רלוונטית <span style="margin-right: 5px;"
                                    data-toggle="tooltip"
                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                            <?php $key = 45; ?>
                            <input type="hidden" name="vals" class="formvalsfile" value="{{ $key }}" />
                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                value="{{ $key }}" />
                            <?php for($z=0; $z<10; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		
	}
	
	$required_val = $file['required'];
								
							
       
        ?>
                            <div id="add_file_line_{{ $key }}" class="add_file_line" {{ $style }}>
                                <div style="display:flex;flex-direction:row;">
                                    <div class="upload-block">
                                        <a href="#" id="rcfile-upload-{{ $key }}" class="rm"
                                            style="display:none"
                                            onclick="removeFile(this,{{ $key }});return false;"><i
                                                class="trash-icon"></i></a>
                                        <input id="{{ $key }}" type="text" disabled class="btn-input-upload"
                                            value="אנא צרף תעודה רלוונטית" />
                                        <label for="cfile-upload-{{ $key }}" class="btn-upload ">
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="19px" height="13px"
                                                style="transform: scale(0.8)  translateY(4px);">
                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                            </svg>
                                            <span style="margin-top:-2px">בחר קובץ</span>
                                        </label>
                                        {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword" required/> --}}
                                        <input id="cfile-upload-{{ $key }}" type="file"
                                            name="file[{{ $key }}]" onchange="fileChange(this)"
                                            accept="application/pdf" {{ $required_val }} />

                                    </div>
                                    <div class="aline">
                                        <button type="button" class="addbutton" onclick="showLineFile(this)"
                                            style="width:30px; height:30px; padding:0;">
                                            <img src="/img/icons/plus.png" />

                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php }?>
                        </div>



                    </div>
                    <hr>
                    <div class="faind_line" style="margin-bottom: 0;">
                        <div class="input-control inline fg2">
                            <label>
                                <span class="caption captiobblue" style="font-weight: bold;">האם עבדת ברשות מקומית
                                    בעבר?</span><br>
                                <label class="radio">
                                    <input type="radio" name="older_worker" value="yes" id="older_worker_yes"
                                        required>
                                    <span class="virtual"></span>
                                    <span class="caption">כן</span>
                                </label>
                                <label class="radio">
                                    <input type="radio" name="older_worker" value="no" required>
                                    <span class="virtual"></span>
                                    <span class="caption">לא</span>
                                </label>
                            </label>
                        </div>
                    </div>
                    <div class="faind_line" style="margin-bottom: 0;">
                        <div class="input-control inline fg2" data-show_type="older_worker_yes" style="">
                            <div>
                                <div class="caption max-w300">תפקיד אחרון ברשות מקומית:</div>
                                <input type="text" name="last_job" class="max-250">
                            </div>
                        </div>
                        <div class="input-control inline fg2" data-show_type="older_worker_yes" style="">
                            <div>
                                <div class="caption max-w300">תאריך התחלה:</div>
                                <input type="date" name="older_start_date">
                            </div>
                        </div>
                        <div class="input-control inline fg2" data-show_type="older_worker_yes" style="">
                            <div>
                                <div class="caption max-w300">תאריך סיום:</div>
                                <input type="date" name="older_end_date">
                            </div>
                        </div>
                        <div class="input-control inline fg2" data-show_type="older_worker_yes" style="">
                            <div>
                                <div class="caption max-w300">סיבת עזיבה:</div>
                                <input id="reason_for_leaving" type="text" name="reason_for_leaving" class="max-250">
                            </div>
                        </div>
                        <div class="input-control inline fg2" data-show_type="older_worker_yes" style="">
                            <div>
                                <span class="caption captiobblue" style="font-weight: bold;">עדיין עובד/ת</span>
                                <label class="radio">
                                    <input type="radio" name="still_working" value="yes" id="still_working"
                                        class="not-required">
                                    <span class="virtual"></span>
                                    <span class="caption"></span>
                                </label>
                            </div>
                        </div>
                        <div class="header_line faind_line">השכלה</div>
                        <div class="faind_line required-c" style="display: flex;">
                            <div class="col-sm space-10">
                                <label class="checkbox">
                                    <input type="checkbox" name="edu_type[]" value="השכלה תיכונית" id="edu_type1">
                                    <span class="virtual"></span>
                                    <span>השכלה תיכונית</span>
                                </label>
                            </div>
                            <div class="col-sm space-10">
                                <label class="checkbox">
                                    <input type="checkbox" name="edu_type[]" value="השכלה על תיכונית" id="edu_type2">
                                    <span class="virtual"></span>
                                    <span>השכלה על תיכונית</span>
                                </label>
                            </div>
                            <div class="col-sm space-10">
                                <label class="checkbox">
                                    <input type="checkbox" name="edu_type[]" value="השכלה גבוהה" id="edu_type3">
                                    <span class="virtual"></span>
                                    <span>השכלה גבוהה</span>
                                </label>
                            </div>
                        </div>
                        <div class="faind_line" data-show_type="edu_type1">
                            <div>
                                <br /><label class="captiobblue bold" style="margin-right:10px">השכלה
                                    תיכונית</label><br />
                            </div>
                            <div id="aline1" class="aline">
                                <div class="input-control fg2">
                                    <div>
                                        <div class="caption captioblack max-w300">שם המוסד</div>
                                        <input type="text" name="educ_institution_name" class="mmax-220"
                                            placeholder="">
                                    </div>
                                </div>
                                <div class="input-control fg2">
                                    <div>
                                        <div class="caption captioblack max-w300">מגמה</div>
                                        <input type="text" name="educ_institution_mode" class="mmax-220"
                                            placeholder="">
                                    </div>
                                </div>
                                <div class="input-control fg2">
                                    <div>
                                        <div class="caption captioblack max-w300">מספר שנות לימוד</div>
                                        <input type="text" name="educ_institution_years_years" class="mmax-220"
                                            placeholder="">
                                    </div>
                                </div>
                                <div class="input-control fg2">
                                    <div>
                                        <div class="caption captioblack max-w300">שנת סיום</div>
                                        <input type="text" name="educ_last_year" class="mmax-220" placeholder="">
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label style="margin-right:10px">תעודה/תואר</label>
                            </div>
                            <div class="required-a" style="display: flex;">
                                <div class="col-sm space-10">
                                    <label class="checkbox">
                                        <input type="checkbox" name="diploma_type[]" value="בגרות">
                                        <span class="virtual"></span>
                                        <span>בגרות</span>
                                    </label>
                                </div>
                                <div class="col-sm space-10">
                                    <label class="checkbox">
                                        <input type="checkbox" name="diploma_type[]" value="בגרות חלקית">
                                        <span class="virtual"></span>
                                        <span>בגרות חלקית</span>
                                    </label>
                                </div>
                                <div class="col-sm space-10">
                                    <label class="checkbox">
                                        <input type="checkbox" name="diploma_type[]" value="גמר ללא תעודה">
                                        <span class="virtual"></span>
                                        <span>גמר ללא תעודה</span>
                                    </label>
                                </div>
                                <div class="col-sm space-10">
                                    <label class="checkbox">
                                        <input type="checkbox" name="diploma_type[]" value="על תיכונית">
                                        <span class="virtual"></span>
                                        <span>על תיכונית</span>
                                    </label>
                                </div>
                                <div class="col-sm space-10">
                                    <div class="btn-input-upload">
                                        <input multiple accept="application/pdf" type="file" name="diploma_type[]"
                                            class="d-none diploma_type" id="diploma_type">
                                        <label class="" for="diploma_type">
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="19px" height="13px"
                                                style="transform: scale(0.8)  translateY(4px);">
                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                            </svg>

                                            <span class="choose-file-text" style="margin-top:-2px">
                                                בחר קובץ
                                            </span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="faind_line" data-show_type="edu_type2">
                            <div>
                                <br /><label class="captiobblue bold" style="margin-right:10px">השכלה על
                                    תיכונית</label><br />
                            </div>
                            <div id="aline1" class="aline">
                                <div class="input-control fg2">
                                    <div>
                                        <div class="caption captioblack max-w300">שם המוסד</div>
                                        <input type="text" name="educ_institution_name" class="mmax-220"
                                            placeholder="">
                                    </div>
                                </div>
                                <div class="input-control fg2">
                                    <div>
                                        <div class="caption captioblack max-w300">מגמה</div>
                                        <input type="text" name="educ_institution_mode" class="mmax-220"
                                            placeholder="">
                                    </div>
                                </div>
                                <div class="input-control fg2">
                                    <div>
                                        <div class="caption captioblack max-w300">מספר שנות לימוד</div>
                                        <input type="text" name="educ_institution_years_years" class="mmax-220"
                                            placeholder="">
                                    </div>
                                </div>
                                <div class="input-control fg2">
                                    <div>
                                        <div class="caption captioblack max-w300">שנת סיום</div>
                                        <input type="text" name="educ_last_year" class="mmax-220" placeholder="">
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label style="margin-right:10px">תעודה/תואר</label>
                            </div>
                            <div class="input-control inline fg2">
                                <label>
                                    <span>תעודת גמר</span>
                                    <label class="radio">
                                        <input type="radio" name="diploma_exist" value="yes">
                                        <span class="virtual"></span>
                                        <span>יש</span>
                                    </label>
                                    <label class="radio">
                                        <input type="radio" name="diploma_exist" value="no">
                                        <span class="virtual"></span>
                                        <span>אין</span>
                                    </label>
                                    <div class="btn-input-upload" style="display: inline-block;">
                                        <input multiple accept="application/pdf" type="file" name="educ_image[]"
                                            class="d-none educ_image" id="educ_image">
                                        <label class="" for="educ_image">
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="19px" height="13px"
                                                style="transform: scale(0.8)  translateY(4px);">
                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                            </svg>

                                            <span class="choose-file-text" style="margin-top:-2px">
                                                בחר קובץ
                                            </span>
                                        </label>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <div class="faind_line" data-show_type="edu_type3">
                            <div id="add_educ1_block" class="add_educ_block">
                                <div id="add_edic1_line" class="add_edic_line" style="clear: both;">
                                    <div>
                                        <br /><label class="captiobblue bold" style="margin-right:10px">השכלה
                                            גבוהה</label><br />
                                    </div>
                                    <div id="aline1" class="aline">
                                        <div class="input-control fg2">
                                            <div>
                                                <div class="caption captioblack max-w300">שם המוסד</div>
                                                <input type="text" name="educ_institution_name" class="mmax-220"
                                                    placeholder="">
                                            </div>
                                        </div>
                                        <div class="input-control fg2">
                                            <div>
                                                <div class="caption captioblack max-w300">מגמה</div>
                                                <input type="text" name="educ_institution_mode" class="mmax-220"
                                                    placeholder="">
                                            </div>
                                        </div>
                                        <div class="input-control fg2">
                                            <div>
                                                <div class="caption captioblack max-w300">מספר שנות לימוד</div>
                                                <input type="text" name="educ_institution_years_years"
                                                    class="mmax-220" placeholder="">
                                            </div>
                                        </div>
                                        <div class="input-control fg2">
                                            <div>
                                                <div class="caption captioblack max-w300">שנת סיום</div>
                                                <input type="text" name="educ_last_year" class="mmax-220"
                                                    placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <label style="margin-right:10px">תעודה/תואר</label>
                                    </div>
                                    <div class="required-b">
                                        <div class="col-sm space-10" style="float: right;">
                                            <label class="checkbox">
                                                <input type="checkbox" name="diploma_high_type[]" value="תואר ראשון">
                                                <span class="virtual"></span>
                                                <span>תואר ראשון</span>
                                            </label>
                                        </div>
                                        <div class="col-sm space-10" style="float: right;">
                                            <label class="checkbox">
                                                <input type="checkbox" name="diploma_high_type[]" value="תואר שני">
                                                <span class="virtual"></span>
                                                <span>תואר שני</span>
                                            </label>
                                        </div>
                                        <div class="col-sm space-10" style="float: right;">
                                            <label class="checkbox">
                                                <input type="checkbox" name="diploma_high_type[]" value="תואר שלישי">
                                                <span class="virtual"></span>
                                                <span>תואר שלישי</span>
                                            </label>
                                        </div>
                                        <div class="col-sm space-10" style="float: right;">
                                            <label class="checkbox">
                                                <input type="checkbox" name="diploma_high_type[]" value="אין">
                                                <span class="virtual"></span>
                                                <span>אין</span>
                                            </label>
                                        </div>
                                        <div class="col-sm space-10" style="float: right;">
                                            <div class="btn-input-upload">
                                                <input multiple accept="application/pdf" type="file"
                                                    name="diplopma_high_image[]" class="d-none diplopma_high_image"
                                                    id="diplopma_high_image">
                                                <label class="" for="diplopma_high_image">
                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="19px"
                                                        height="13px" style="transform: scale(0.8)  translateY(4px);">
                                                        <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                            d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                    </svg>

                                                    <span class="choose-file-text" style="margin-top:-2px">
                                                        בחר קובץ
                                                    </span>
                                                </label>
                                            </div>
                                            <a href="#" class="closebtn"
                                                style='visibility:hidden;margin-top:25px;float:left'
                                                onclick="closeLine(this)"><img src="/img/close-lg.png" /></a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="aline" style="flex-direction: row-reverse;clear: both;"
                                data-show_type="edu_type3">
                                <button type="button" class="addbutton leftbtn"
                                    onclick="dublibe('add_educ1_block','add_edic1_line')">
                                    <img src="/img/icons/plus.png" />
                                    הוסף שורה
                                </button>
                            </div>
                            <br>
                            <div>
                                <div class="header_line faind_line"> קורסים והשתלמויות בתחום המקצועי הרלוונטי לתפקיד
                                    ב{{ $textChange }}</div>
                                <div id="add_educ_block" class="add_educ_block">
                                    <div id="add_edic_line" class="add_edic_line">
                                        <div class="input-control">
                                            <div>
                                                <div class="caption max-w300">שם הקורס / השתלמות</div>
                                                <input type="text" name="add_educ_name[]" class="max-220"
                                                    placeholder="">
                                            </div>
                                        </div>
                                        <div class="input-control">
                                            <div>
                                                <div class="caption max-w300">תאריך סיום</div>
                                                <input type="date" name="add_educ_finish[]" class="max-220">
                                            </div>
                                        </div>
                                        <div class="input-control">
                                            <div>
                                                <div class="caption max-w300">מסגרת לימודים</div>
                                                <input type="text" name="add_educ_desc[]" class="max-220"
                                                    placeholder="">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr file-block">
                                            <div class="caption max-w300">אנא צרף תעודה רלוונטית <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                                            <?php// $key = 0; ?> ?> ?>
                                            <?php $key = 35; ?>
                                            <input type="hidden" name="vals" class="formvalsfile"
                                                value="{{ $key }}" />
                                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                value="{{ $key }}" />
                                            <?php for($z=0; $z<10; $z++,$key++){
		$file = $form_file[$key];
		if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		
	}

	

	
	$required_val = $file['required'];
								
							
       
        ?>
                                            <div id="add_file_line_{{ $key }}" class="add_file_line"
                                                {{ $style }}>
                                                <div style="display:flex;flex-direction:row;">
                                                    <div class="upload-block">

                                                        <a href="#" id="rcfile-upload-{{ $key }}"
                                                            class="rm" style="display:none"
                                                            onclick="removeFile(this,{{ $key }});return false;"><i
                                                                class="trash-icon"></i></a>
                                                        <input id="{{ $key }}" type="text" disabled
                                                            class="btn-input-upload educ"
                                                            value="אנא צרף תעודה רלוונטית" />
                                                        <label for="cfile-upload-{{ $key }}"
                                                            class="btn-upload ">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                width="19px" height="13px"
                                                                style="transform: scale(0.8)  translateY(4px);">
                                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                            </svg>
                                                            <span style="margin-top:-2px">

                                                                בחר קובץ
                                                            </span>
                                                        </label>
                                                        {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword" data-val="educ"/> --}}
                                                        <input id="cfile-upload-{{ $key }}" type="file"
                                                            name="file[{{ $key }}]"
                                                            onchange="fileChange(this)" accept="application/pdf"
                                                            data-val="educ" {{ $required_val }} />

                                                    </div>
                                                    <div class="aline">
                                                        <button type="button" class="addbutton"
                                                            onclick="showLineFile(this)"
                                                            style="width:30px; height:30px; padding:0;">
                                                            <img src="/img/icons/plus.png" />

                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <a href="#" class="closebtn"
                                            style='visibility:hidden;margin-top:25px;float:left'
                                            onclick="closeLine(this)"><img src="/img/close-lg.png" /></a>
                                    </div>
                                    <input type="hidden" name="vals" id="formvalsedu" value="0" />
                                    <?php $key = 143; ?>
                                    @for ($i = 0; $i < 9; $i++)
                                        <?php
                                        $req = $i < 0 ? 'required' : '';
                                        ?>
                                        <div id="add_edic_line_{{ $i }}" class="add_edic_line aline"
                                            style="display:none">
                                            <div class="input-control">
                                                <div>
                                                    <div class="caption max-w300">שם הקורס / השתלמות</div>
                                                    <input type="text" name="add_educ_name[]" class="max-220"
                                                        placeholder="">
                                                </div>
                                            </div>
                                            <div class="input-control">
                                                <div>
                                                    <div class="caption max-w300">תאריך סיום</div>
                                                    <input type="date" name="add_educ_finish[]" class="max-220">
                                                </div>
                                            </div>
                                            <div class="input-control">
                                                <div>
                                                    <div class="caption max-w300">מסגרת לימודים</div>
                                                    <input type="text" name="add_educ_desc[]" class="max-220"
                                                        placeholder="">
                                                </div>
                                            </div>
                                            <div class="input-control btn-descr file-block">
                                                <div class="caption max-w300">אנא צרף תעודה רלוונטית <span
                                                        style="margin-right: 5px;" data-toggle="tooltip"
                                                        title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                            class="fas fa-info-circle" aria-hidden="true"></i></span>
                                                </div>

                                                <?php// $key = $i + 35; $file = $form_file[$key];?> ?> ?>

                                                <input type="hidden" name="vals" class="formvalsfile"
                                                    value="{{ $key }}" />
                                                <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                    value="{{ $key }}" />
                                                <?php for($z=0; $z<10; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		
	}
	
	$required_val = $file['required'];
								
							
       
        ?>
                                                <div id="add_file_line_{{ $key }}" class="add_file_line"
                                                    {{ $style }}>
                                                    <div style="display:flex;flex-direction:row;">
                                                        <div class="upload-block">

                                                            <a href="#" id="rcfile-upload-{{ $key }}"
                                                                class="rm" style="display:none"
                                                                onclick="removeFile(this,{{ $key }});return false;"><i
                                                                    class="trash-icon"></i></a>
                                                            <input id="{{ $key }}" type="text" disabled
                                                                class="btn-input-upload educ"
                                                                value="אנא צרף תעודה רלוונטית" />
                                                            <label for="cfile-upload-{{ $key }}"
                                                                class="btn-upload ">
                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                    xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                    width="19px" height="13px"
                                                                    style="transform: scale(0.8)  translateY(4px);">
                                                                    <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                        d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                                </svg>
                                                                <span style="margin-top:-2px">

                                                                    בחר קובץ
                                                                </span>
                                                            </label>
                                                            {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword" data-val="educ"/> --}}
                                                            <input id="cfile-upload-{{ $key }}"
                                                                type="file" name="file[{{ $key }}]"
                                                                onchange="fileChange(this)" accept="application/pdf"
                                                                data-val="educ" {{ $required_val }} />

                                                        </div>
                                                        <div class="aline">
                                                            <button type="button" class="addbutton"
                                                                onclick="showLineFile(this)"
                                                                style="width:30px; height:30px; padding:0;">
                                                                <img src="/img/icons/plus.png" />

                                                            </button>
                                                        </div>


                                                    </div>
                                                </div>
                                                <?php } ?>
                                            </div>
                                            <a href="#" class="closebtn"
                                                style='visibility:hidden;margin-top:25px;float:left'
                                                onclick="closeLine(this)"><img src="/img/close-lg.png" /></a>
                                        </div>
                                    @endfor
                                </div>
                                <div class="aline" style="flex-direction: row-reverse">
                                    <button type="button" class="addbutton leftbtn" onclick="showLineEdu()">
                                        <img src="/img/icons/plus.png" />
                                        הוסף שורה
                                    </button>
                                </div>

                                <div class="aline">
                                    <div>
                                        <label style="margin-right:10px">תעודה/תואר</label>
                                    </div>
                                    <div class="input-control inline fg2">
                                        <label>
                                            <span>תעודת גמר</span>
                                            <label class="radio">
                                                <input type="radio" name="diploma_exist_relevant" value="yes">
                                                <span class="virtual"></span>
                                                <span>יש</span>
                                            </label>
                                            <label class="radio">
                                                <input type="radio" name="diploma_exist_relevant" value="no">
                                                <span class="virtual"></span>
                                                <span>אין</span>
                                            </label>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="header_line faind_line">רישיון/ רישום בפנקס מקצועי</div>
                            <div class="faind_line">
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label class="checkbox">
                                            <input type="checkbox" id="job1" name="job[1]"
                                                value="מהנדסים/אדריכלים">
                                            <span class="virtual"></span>
                                            <span class="caption">מהנדסים/אדריכלים</span>
                                        </label>
                                    </div>
                                    <div class="col-lg-10" data-show_type="job1">
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מספר רשיון:</div>
                                                <input type="text" name="license[1]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">סוג רשיון:</div>
                                                <input type="text" name="license_type[1]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מועד קבלת הרישיון:</div>
                                                <input type="date" name="license_date[1]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr file-block">
                                            <div class="caption max-w300">אנא צרף צילום רישיון <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                                            <?php $key = 343; ?>

                                            <input type="hidden" name="vals" class="formvalsfile"
                                                value="{{ $key }}" />
                                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                value="{{ $key }}" />
                                            <?php for($z=0; $z<1; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		
	}
	
	$required_val = $file['required'];
								
							
       
        ?>
                                            <div id="add_file_line_{{ $key }}" class="add_file_line"
                                                {{ $style }}>
                                                <div style="display:flex;flex-direction:row;">
                                                    <div class="upload-block">
                                                        <a href="#" id="rcfile-upload-{{ $key }}"
                                                            class="rm" style="display:none"
                                                            onclick="removeFile(this,{{ $key }});return false;"><i
                                                                class="trash-icon"></i></a>
                                                        <input id="{{ $key }}" type="text" disabled
                                                            class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                        <label for="cfile-upload-{{ $key }}"
                                                            class="btn-upload ">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                width="19px" height="13px"
                                                                style="transform: scale(0.8)  translateY(4px);">
                                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                            </svg>
                                                            <span style="margin-top:-2px">
                                                                בחר קובץ
                                                            </span>
                                                        </label>
                                                        {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                        <input id="cfile-upload-{{ $key }}" type="file"
                                                            name="file[{{ $key }}]"
                                                            onchange="fileChange(this)"
                                                            accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword" />
                                                    </div>

                                                </div>
                                            </div>
                                            <?php } ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label class="checkbox">
                                            <input type="checkbox" id="job2" name="job[2]"
                                                value="טכנאים/הנדסאים">
                                            <span class="virtual"></span>
                                            <span class="caption">טכנאים/הנדסאים</span>
                                        </label>
                                    </div>
                                    <div class="col-lg-10" data-show_type="job2">
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מספר רשיון:</div>
                                                <input type="text" name="license[2]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">סוג רשיון:</div>
                                                <input type="text" name="license_type[2]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מועד קבלת הרישיון:</div>
                                                <input type="date" name="license_date[2]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr file-block">
                                            <div class="caption max-w300">אנא צרף צילום רישיון <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>
                                            <?php $key = 353; ?>

                                            <input type="hidden" name="vals" class="formvalsfile"
                                                value="{{ $key }}" />
                                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                value="{{ $key }}" />
                                            <?php for($z=0; $z<1; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		
	}
	
	$required_val = $file['required'];
								
							
       
        ?>
                                            <div id="add_file_line_{{ $key }}" class="add_file_line"
                                                {{ $style }}>
                                                <div style="display:flex;flex-direction:row;">
                                                    <div class="upload-block">
                                                        <a href="#" id="rcfile-upload-{{ $key }}"
                                                            class="rm" style="display:none"
                                                            onclick="removeFile(this,{{ $key }});return false;"><i
                                                                class="trash-icon"></i></a>
                                                        <input id="{{ $key }}" type="text" disabled
                                                            class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                        <label for="cfile-upload-{{ $key }}"
                                                            class="btn-upload ">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                width="19px" height="13px"
                                                                style="transform: scale(0.8)  translateY(4px);">
                                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                            </svg>
                                                            <span style="margin-top:-2px">

                                                                בחר קובץ
                                                            </span>
                                                        </label>
                                                        {{-- <input id="cfile-upload-72" type="file" name="file[72]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                        <input id="cfile-upload-{{ $key }}" type="file"
                                                            name="file[{{ $key }}]"
                                                            onchange="fileChange(this)" accept="application/pdf" />

                                                    </div>
                                                    {{-- <div class="aline"  >
			<button type="button" class="addbutton" onclick="showLineFile(this)" style="width:30px; height:30px; padding:0;">
				<img src="/img/icons/plus.png"  />
					
			</button>
		</div> --}}
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label class="checkbox">
                                            <input type="checkbox" id="job3" name="job[3]"
                                                value="עובדים סוציאליים">
                                            <span class="virtual"></span>
                                            <span class="caption">עובדים סוציאליים</span>
                                        </label>
                                    </div>
                                    <div class="col-lg-10" data-show_type="job3">
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מספר רשיון:</div>
                                                <input type="text" name="license[3]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">סוג רשיון:</div>
                                                <input type="text" name="license_type[3]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מועד קבלת הרישיון:</div>
                                                <input type="date" name="license_date[3]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr file-block">
                                            <div class="caption max-w300">אנא צרף צילום רישיון <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>
                                            <?php $key = 363; ?>

                                            <input type="hidden" name="vals" class="formvalsfile"
                                                value="{{ $key }}" />
                                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                value="{{ $key }}" />
                                            <?php for($z=0; $z<1; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		
	}
	
	$required_val = $file['required'];
								
							
       
        ?>
                                            <div id="add_file_line_{{ $key }}" class="add_file_line"
                                                {{ $style }}>
                                                <div style="display:flex;flex-direction:row;">
                                                    <div class="upload-block">
                                                        <a href="#" id="rcfile-upload-{{ $key }}"
                                                            class="rm" style="display:none"
                                                            onclick="removeFile(this,{{ $key }});return false;"><i
                                                                class="trash-icon"></i></a>
                                                        <input id="{{ $key }}" type="text" disabled
                                                            class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                        <label for="cfile-upload-{{ $key }}"
                                                            class="btn-upload ">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                width="19px" height="13px"
                                                                style="transform: scale(0.8)  translateY(4px);">
                                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                            </svg>
                                                            <span style="margin-top:-2px">

                                                                בחר קובץ
                                                            </span>
                                                        </label>
                                                        {{-- <input id="cfile-upload-73" type="file" name="file[73]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                        <input id="cfile-upload-{{ $key }}" type="file"
                                                            name="file[{{ $key }}]"
                                                            onchange="fileChange(this)"
                                                            accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword" />
                                                    </div>
                                                    {{-- <div class="aline"  >
			<button type="button" class="addbutton" onclick="showLineFile(this)" style="width:30px; height:30px; padding:0;">
				<img src="/img/icons/plus.png"  />
					
			</button>
		</div> --}}
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>


                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label class="checkbox">
                                            <input type="checkbox" id="job4" name="job[4]" value="עריכת דין">
                                            <span class="virtual"></span>
                                            <span class="caption">עריכת דין</span>
                                        </label>
                                    </div>
                                    <div class="col-lg-10" data-show_type="job4">
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מספר רשיון:</div>
                                                <input type="text" name="license[4]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">סוג רשיון:</div>
                                                <input type="text" name="license_type[4]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מועד קבלת הרישיון:</div>
                                                <input type="date" name="license_date[4]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr">
                                            <div class="caption max-w300">אנא צרף צילום רישיון <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>
                                            <div>
                                                <div class="upload-block">
                                                    <a href="#" id="rcfile-upload-373" class="rm"
                                                        style="display:none"
                                                        onclick="removeFile(this,74);return false;"><i
                                                            class="trash-icon"></i></a>
                                                    <input id="373" type="text" disabled
                                                        class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                    <label for="cfile-upload-373" class="btn-upload ">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            xmlns:xlink="http://www.w3.org/1999/xlink" width="19px"
                                                            height="13px"
                                                            style="transform: scale(0.8)  translateY(4px);">
                                                            <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                        </svg>
                                                        <span style="margin-top:-2px">

                                                            בחר קובץ
                                                        </span>
                                                    </label>
                                                    {{-- <input id="cfile-upload-74" type="file" name="file[74]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                    <input id="cfile-upload-373" type="file" name="file[373]"
                                                        onchange="fileChange(this)" accept="application/pdf" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label class="checkbox">
                                            <input type="checkbox" id="job5" name="job[5]"
                                                value="ראיית חשבון">
                                            <span class="virtual"></span>
                                            <span class="caption">ראיית חשבון</span>
                                        </label>
                                    </div>
                                    <div class="col-lg-10" data-show_type="job5">
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מספר רשיון:</div>
                                                <input type="text" name="license[5]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">סוג רשיון:</div>
                                                <input type="text" name="license_type[5]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מועד קבלת הרישיון:</div>
                                                <input type="date" name="license_date[5]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr">
                                            <div class="caption max-w300">אנא צרף צילום רישיון <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>
                                            <div>
                                                <div class="upload-block">
                                                    <a href="#" id="rcfile-upload-383" class="rm"
                                                        style="display:none"
                                                        onclick="removeFile(this,383);return false;"><i
                                                            class="trash-icon"></i></a>
                                                    <input id="383" type="text" disabled
                                                        class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                    <label for="cfile-upload-383" class="btn-upload ">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            xmlns:xlink="http://www.w3.org/1999/xlink" width="19px"
                                                            height="13px"
                                                            style="transform: scale(0.8)  translateY(4px);">
                                                            <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                        </svg>
                                                        <span style="margin-top:-2px">

                                                            בחר קובץ
                                                        </span>
                                                    </label>
                                                    {{-- <input id="cfile-upload-75" type="file" name="file[75]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                    <input id="cfile-upload-383" type="file" name="file[383]"
                                                        onchange="fileChange(this)" accept="application/pdf" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label class="checkbox">
                                            <input type="checkbox" id="job6" name="job[6]" value="אחיות">
                                            <span class="virtual"></span>
                                            <span class="caption">אחיות</span>
                                        </label>
                                    </div>
                                    <div class="col-lg-10" data-show_type="job6">
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מספר רשיון:</div>
                                                <input type="text" name="license[6]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">סוג רשיון:</div>
                                                <input type="text" name="license_type[6]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מועד קבלת הרישיון:</div>
                                                <input type="date" name="license_date[6]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr">
                                            <div class="caption max-w300">אנא צרף צילום רישיון <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>
                                            <div>
                                                <div class="upload-block">
                                                    <a href="#" id="rcfile-upload-393" class="rm"
                                                        style="display:none"
                                                        onclick="removeFile(this,393);return false;"><i
                                                            class="trash-icon"></i></a>
                                                    <input id="393" type="text" disabled
                                                        class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                    <label for="cfile-upload-393" class="btn-upload ">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            xmlns:xlink="http://www.w3.org/1999/xlink" width="19px"
                                                            height="13px"
                                                            style="transform: scale(0.8)  translateY(4px);">
                                                            <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                        </svg>
                                                        <span style="margin-top:-2px">

                                                            בחר קובץ
                                                        </span>
                                                    </label>
                                                    {{-- <input id="cfile-upload-76" type="file" name="file[76]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                    <input id="cfile-upload-393" type="file" name="file[393]"
                                                        onchange="fileChange(this)" accept="application/pdf" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label class="checkbox">
                                            <input type="checkbox" id="job7" name="job[7]" value="רפואה">
                                            <span class="virtual"></span>
                                            <span class="caption">רפואה</span>
                                        </label>
                                    </div>
                                    <div class="col-lg-10" data-show_type="job7">
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מספר רשיון:</div>
                                                <input type="text" name="license[7]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">סוג רשיון:</div>
                                                <input type="text" name="license_type[7]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מועד קבלת הרישיון:</div>
                                                <input type="date" name="license_date[7]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr">
                                            <div class="caption max-w300">אנא צרף צילום רישיון <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>
                                            <div>
                                                <div class="upload-block">
                                                    <a href="#" id="rcfile-upload-403" class="rm"
                                                        style="display:none"
                                                        onclick="removeFile(this,77);return false;"><i
                                                            class="trash-icon"></i></a>
                                                    <input id="403" type="text" disabled
                                                        class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                    <label for="cfile-upload-403" class="btn-upload ">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            xmlns:xlink="http://www.w3.org/1999/xlink" width="19px"
                                                            height="13px"
                                                            style="transform: scale(0.8)  translateY(4px);">
                                                            <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                        </svg>
                                                        <span style="margin-top:-2px">

                                                            בחר קובץ
                                                        </span>
                                                    </label>
                                                    {{-- <input id="cfile-upload-403" type="file" name="file[403]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                    <input id="cfile-upload-403" type="file" name="file[403]"
                                                        onchange="fileChange(this)" accept="application/pdf" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label class="checkbox">
                                            <input type="checkbox" id="job8" name="job[8]"
                                                value="תעודת רישיון אחר">
                                            <span class="virtual"></span>
                                            <span class="caption">תעודת רישיון אחר</span>
                                        </label>
                                    </div>
                                    <div class="col-lg-10" data-show_type="job8">
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מספר רשיון:</div>
                                                <input type="text" name="license[8]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">סוג רשיון:</div>
                                                <input type="text" name="license_type[8]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control inline fg2">
                                            <div>
                                                <div class="caption max-w180">מועד קבלת הרישיון:</div>
                                                <input type="date" name="license_date[8]" class="max-275">
                                            </div>
                                        </div>
                                        <div class="input-control btn-descr">
                                            <div class="caption max-w300">אנא צרף צילום רישיון <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>
                                            <div>
                                                <div class="upload-block">
                                                    <a href="#" id="rcfile-upload-413" class="rm"
                                                        style="display:none"
                                                        onclick="removeFile(this,413);return false;"><i
                                                            class="trash-icon"></i></a>
                                                    <input id="413" type="text" disabled
                                                        class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                    <label for="cfile-upload-413" class="btn-upload ">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            xmlns:xlink="http://www.w3.org/1999/xlink" width="19px"
                                                            height="13px"
                                                            style="transform: scale(0.8)  translateY(4px);">
                                                            <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                        </svg>
                                                        <span style="margin-top:-2px">

                                                            בחר קובץ
                                                        </span>
                                                    </label>
                                                    {{-- <input id="cfile-upload-413" type="file" name="file[413]"
								   onchange="fileChange(this)"
								   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                    <input id="cfile-upload-413" type="file" name="file[413]"
                                                        onchange="fileChange(this)" accept="application/pdf" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="header_line faind_line">רשיונות נהיגה/בעלות על רכב</div>
                        <div class="faind_line" style="display: flex;">
                            <div class="input-control inline fg2">
                                <label>
                                    <div class="caption bold">רשיונות נהיגה</div>
                                    <label class="radio">
                                        <input type="radio" name="license_exist" value="yes" required="true"
                                            id="license_exist_yes">
                                        <span class="virtual"></span>
                                        <span>יש</span>
                                    </label>
                                    <label class="radio">
                                        <input type="radio" name="license_exist" value="no" required="true">
                                        <span class="virtual"></span>
                                        <span>אין</span>
                                    </label>
                                </label>
                            </div>
                            <div class="input-control inline fg2">
                                <label>
                                    <div class="caption bold">בעלות על רכב</div>
                                    <label class="radio">
                                        <input type="radio" name="car_exist" value="yes" required="true">
                                        <span class="virtual"></span>
                                        <span>יש</span>
                                    </label>
                                    <label class="radio">
                                        <input type="radio" name="car_exist" value="no" required="true">
                                        <span class="virtual"></span>
                                        <span>אין</span>
                                    </label>
                                </label>
                            </div>
                            <div class="input-control inline fg2">
                                <!--<label>
            <div class="caption bold">סוג הרשיון</div>
            <select name="car_license_type" multiple>
             <option></option>
             <option value="a">אופנוע</option>
             <option value="b">רכב עד 3.5 טון ועד 8 נוסעים</option>
             <option value="c">רכב משא</option>
             <option value="d">אוטובוסים ומוניות</option>
             <option value="1">טרקטור</option>
            </select>
           </label>-->

                                <div>
                                    <div class="caption bold">סוג הרשיון</div>
                                    <label class="checkbox" style="margin-left: 10px; margin-top: 0;">
                                        <input type="checkbox" name="car_license_type[]" value="אופנוע">
                                        <span class="virtual"></span>
                                        <span class="caption">אופנוע</span>
                                    </label>
                                    <label class="checkbox" style="margin-left: 10px; margin-top: 0;">
                                        <input type="checkbox" name="car_license_type[]"
                                            value="רכב עד 3.5 טון ועד 8 נוסעים">
                                        <span class="virtual"></span>
                                        <span class="caption">רכב עד 3.5 טון ועד 8 נוסעים</span>
                                    </label>
                                    <label class="checkbox" style="margin-left: 10px; margin-top: 0;">
                                        <input type="checkbox" name="car_license_type[]" value="רכב משא">
                                        <span class="virtual"></span>
                                        <span class="caption">רכב משא</span>
                                    </label>
                                    <label class="checkbox" style="margin-left: 10px; margin-top: 0;">
                                        <input type="checkbox" name="car_license_type[]" value="אוטובוסים ומוניות">
                                        <span class="virtual"></span>
                                        <span class="caption">אוטובוסים ומוניות</span>
                                    </label>
                                    <label class="checkbox" style="margin-left: 10px; margin-top: 0;">
                                        <input type="checkbox" name="car_license_type[]" value="טרקטור">
                                        <span class="virtual"></span>
                                        <span class="caption">טרקטור</span>
                                    </label>
                                </div>
                            </div>
                            <div class="input-control btn-descr file-block" data-show_type="license_exist_yes">
                                <div class="caption max-w300">אנא צרף צילום רישיון <span style="margin-right: 5px;"
                                        data-toggle="tooltip"
                                        title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                            class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                                <?php $key = 233; ?>
                                <input type="hidden" name="vals" class="formvalsfile"
                                    value="{{ $key }}" />
                                <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                    value="{{ $key }}" />
                                <?php for($z=0; $z<10; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
	$required_val="required=document.getElementById('license_exist_yes').checked";
	}else{
		$style = "style=display:none";
		$required_val= "";
		
	}
	
	
								
							
       
        ?>
                                <div id="add_file_line_{{ $key }}" class="add_file_line"
                                    {{ $style }}>
                                    <div style="display:flex;flex-direction:row;">
                                        <div class="upload-block">

                                            <a href="#" id="rcfile-upload-{{ $key }}" class="rm"
                                                style="display:none"
                                                onclick="removeFile(this,{{ $key }});return false;"><i
                                                    class="trash-icon"></i></a>
                                            <input id="{{ $key }}" type="text" disabled
                                                class="btn-input-upload data-val" value="אנא צרף תעודה רלוונטית" />
                                            <label for="cfile-upload-{{ $key }}" class="btn-upload ">
                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                    xmlns:xlink="http://www.w3.org/1999/xlink" width="19px"
                                                    height="13px" style="transform: scale(0.8)  translateY(4px);">
                                                    <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                        d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                </svg>
                                                <span style="margin-top:-2px">

                                                    בחר קובץ
                                                </span>
                                            </label>
                                            {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
						   onchange="fileChange(this)"
						   accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword" required="document.getElementById('license_exist_yes').checked"/> --}}
                                            <input id="cfile-upload-{{ $key }}" type="file"
                                                name="file[{{ $key }}]" onchange="fileChange(this)"
                                                accept="application/pdf" {{ $required_val }} />

                                        </div>
                                        <div class="aline">
                                            <button type="button" class="addbutton" onclick="showLineFile(this)"
                                                style="width:30px; height:30px; padding:0;">
                                                <img src="/img/icons/plus.png" />

                                            </button>
                                        </div>

                                    </div>
                                </div>
                                <?php }?>
                            </div>
                        </div>
                        <div class="header_line faind_line">
                            שפות
                        </div>
                        <div class="faind_line">
                            <div id="ivrblock" style="">
                                <div class="input-control inline">
                                    <div>
                                        <div class="caption max-w300">השפה</div>
                                        <input type="text" name="language_i[]" value="עברית" disabled
                                            required="" class="max-220" placeholder="">
                                    </div>
                                </div>
                                <div class="input-control inline" id="id1">
                                    <div>
                                        <div class="caption max-w300">קריאה</div>
                                        <select name="language_read_i" class="max-220" required="">
                                            <option></option>
                                            <option value="שליטה מלאה">שליטה מלאה</option>
                                            <option value="שליטה חלקית">שליטה חלקית</option>
                                            <option value="חוסר שליטה">חוסר שליטה</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="input-control inline" id="id2">
                                    <div>
                                        <div class="caption max-w300">כתיבה</div>
                                        <select name="language_write_i" class="max-220" required="">
                                            <option></option>
                                            <option value="שליטה מלאה">שליטה מלאה</option>
                                            <option value="שליטה חלקית">שליטה חלקית</option>
                                            <option value="חוסר שליטה">חוסר שליטה</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="input-control inline">
                                    <div>
                                        <div class="caption max-w300">דיבור</div>
                                        <select name="language_speak_i" class="max-220" required="">
                                            <option></option>
                                            <option value="שליטה מלאה">שליטה מלאה</option>
                                            <option value="שליטה חלקית">שליטה חלקית</option>
                                            <option value="חוסר שליטה">חוסר שליטה</option>
                                        </select>
                                    </div>
                                </div>
                                <a href="#" class="closebtn" style='visibility:hidden;margin-top:25px'
                                    onclick="closeLine(this)"><img src="/img/close-lg.png" /></a>

                            </div>
                            <div id="eblock">
                                <div class="input-control inline">
                                    <div>
                                        <div class="caption max-w300">השפה</div>
                                        <input type="text" name="language_e[]" value="אנגלית" disabled
                                            required="" class="max-220" placeholder="">
                                    </div>
                                </div>
                                <div class="input-control inline">
                                    <div>
                                        <div class="caption max-w300">קריאה</div>
                                        <select name="language_read_e" class="max-220" required="">
                                            <option></option>
                                            <option value="שליטה מלאה">שליטה מלאה</option>
                                            <option value="שליטה חלקית">שליטה חלקית</option>
                                            <option value="חוסר שליטה">חוסר שליטה</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="input-control inline">
                                    <div>
                                        <div class="caption max-w300">כתיבה</div>
                                        <select name="language_write_e" class="max-220" required="">
                                            <option></option>
                                            <option value="שליטה מלאה">שליטה מלאה</option>
                                            <option value="שליטה חלקית">שליטה חלקית</option>
                                            <option value="חוסר שליטה">חוסר שליטה</option>
                                        </select>

                                    </div>
                                </div>
                                <div class="input-control inline">
                                    <div>
                                        <div class="caption max-w300">דיבור</div>
                                        <select name="language_speak_e" class="max-220" required="">
                                            <option></option>
                                            <option value="שליטה מלאה">שליטה מלאה</option>
                                            <option value="שליטה חלקית">שליטה חלקית</option>
                                            <option value="חוסר שליטה">חוסר שליטה</option>
                                        </select>
                                    </div>
                                </div>
                                <a href="#" class="closebtn" style='visibility:hidden;margin-top:25px'
                                    onclick="closeLine(this)"><img src="/img/close-lg.png" /></a>

                            </div>
                            <div class="language_block" id="language_block">
                                <div id="language_line" style="display:none">
                                    <div class="input-control inline">
                                        <div>
                                            <div class="caption max-w300">השפה</div>
                                            <input type="text" name="language[]" class="max-220" placeholder="">
                                        </div>
                                    </div>
                                    <div class="input-control inline">
                                        <div>
                                            <div class="caption max-w300">קריאה</div>
                                            <select name="language_write_[]" class="max-220">
                                                <option></option>
                                                <option value="שליטה מלאה">שליטה מלאה</option>
                                                <option value="שליטה חלקית">שליטה חלקית</option>
                                                <option value="חוסר שליטה">חוסר שליטה</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="input-control inline">
                                        <div>
                                            <div class="caption max-w300">כתיבה</div>
                                            <select name="language_write_[]" class="max-220">
                                                <option></option>
                                                <option value="שליטה מלאה">שליטה מלאה</option>
                                                <option value="שליטה חלקית">שליטה חלקית</option>
                                                <option value="חוסר שליטה">חוסר שליטה</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="input-control inline">
                                        <div>
                                            <div class="caption max-w300">דיבור</div>

                                            <select name="language_speak_[]" class="max-220">
                                                <option></option>
                                                <option value="שליטה מלאה">שליטה מלאה</option>
                                                <option value="שליטה חלקית">שליטה חלקית</option>
                                                <option value="חוסר שליטה">חוסר שליטה</option>
                                            </select>
                                        </div>
                                    </div>
                                    <a href="#" class="closebtn" style='visibility:hidden;margin-top:25px'
                                        onclick="closeLine(this)"><img src="/img/close-lg.png" /></a>
                                </div>
                            </div>
                        </div>
                        <div class="aline" style="flex-direction: row-reverse">
                            <div class="input-control leftbtn">
                                <button type="button" class="addbutton"
                                    onclick="dublibe('language_block','language_line')">
                                    <img src="/img/icons/plus.png" />
                                    הוסף שורה
                                </button>
                            </div>
                        </div>
                        <div>
                                <div class="header_line faind_line">
                                    ממליצים
                                </div>
                                <div id="recomendations_block">
                                    <div id="recomendations_line">
                                        <div class="input-control">
                                            <div>
                                                <div class="caption max-w300">שם פרטי + שם משפחה</div>
                                                <input @required($tender->is_recommended == 1) type="text" name="recomendations_name_z[]" class="max-220"
                                                    placeholder="">
                                            </div>
                                        </div>
                                        <div class="input-control">
                                            <div>
                                                <div class="caption max-w300">תפקיד / מקצוע</div>
                                                <input @required($tender->is_recommended == 1) type="text" name="recomendations_role_z[]" class="max-220"
                                                    placeholder="">
                                            </div>
                                        </div>
                                        <div class="input-control">
                                            <div>
                                                <div class="caption max-w300">מקום עבודה</div>
                                                <input @required($tender->is_recommended == 1) type="text" name="recomendations_work_place[]"
                                                    class="max-220" placeholder="">
                                            </div>
                                        </div>
                                        <div class="input-control inline">
                                            <label>
                                                <div class="caption max-w180">מספר נייד / מספר טלפון</div>
                                                <input @required($tender->is_recommended == 1) type="text" name="recomendations_phone_z[]"
                                                    pattern="^[0-9]+$" minlength="7" maxlength="7"
                                                    class="max-130">
                                            </label>
                                            <select @required($tender->is_recommended == 1) class="max-65 phn" name="recomendations_mobile_phone1_select_z[]"
                                                style="margin-right: -23px;transform:translateY(-1px)">
                                                <option value="050">050</option>
                                                <option value="052"> 052</option>
                                                <option value="053"> 053</option>
                                                <option value="054"> 054</option>
                                                <option value="055"> 055</option>
                                                <option value="057"> 057</option>
                                                <option value="058"> 058</option>
                                            </select>
                                        </div>
                                        <div class="input-control file-block" style="transform:translateY(-8px)">

                                            <div class="caption max-w300">אנא צרף מכתב המלצה <span
                                                    style="margin-right: 5px;" data-toggle="tooltip"
                                                    title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                        class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                                            <?php //$key = 1; $file = $form_file[$key];
                                            ?>
                                            <?php $key = 13; ?>
                                            <input type="hidden" name="vals" class="formvalsfile"
                                                value="{{ $key }}" />
                                            <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                value="{{ $key }}" />
                                            <?php for($z=0; $z<10; $z++,$key++){
                                            $file = $form_file[$key];
                                            
                                            if($z==0){
                                                $style= "";
                                            }else{
                                                $style = "style=display:none";
                                                
                                            }
                                            
                                            $required_val = $file['required'];
                                                                        
                                                                    
                                            
                                                ?>
                                            <div id="add_file_line_{{ $key }}" class="add_file_line"
                                                {{ $style }}>
                                                <div style="display:flex;flex-direction:row;">
                                                    <div class="upload-block">
                                                        <a href="#" id="rcfile-upload-{{ $key }}"
                                                            class="rm" style="display:none"
                                                            onclick="removeFile(this,'{{ $key }}');return false;"><i
                                                                class="trash-icon"></i></a>
                                                        <input @required($tender->is_recommended == 1) id="{{ $key }}" type="text" disabled
                                                            class="btn-input-upload recomendations"
                                                            value="אנא צרף תעודה רלוונטית" />
                                                        <label for="cfile-upload-{{ $key }}"
                                                            class="btn-upload ">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                width="19px" height="13px"
                                                                style="transform: scale(0.8)  translateY(4px);">
                                                                <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                    d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                            </svg>
                                                            <span style="margin-top:-2px">

                                                                בחר קובץ
                                                            </span>

                                                        </label>
                                                        {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
										onchange="fileChange(this)"
										accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"
										data-val="recomendations"/> --}}
                                                        <input id="cfile-upload-{{ $key }}" type="file"
                                                            name="file[{{ $key }}]"
                                                            onchange="fileChange(this)" accept="application/pdf"
                                                            data-val="recomendations" $required_val />

                                                    </div>

                                                    <div class="aline">
                                                        <button type="button" class="addbutton"
                                                            onclick="showLineFile(this)"
                                                            style="width:30px; height:30px; padding:0;">
                                                            <img src="/img/icons/plus.png" />

                                                        </button>
                                                    </div>
                                                </div>

                                            </div>
                                            <?php } ?>
                                        </div>


                                    </div>
                                    <input type="hidden" name="vals" id="formvals" value="0" />
                                    <?php $key = 243; ?>
                                    @for ($i = 0; $i < 9; $i++)
                                        <?php
                                        $req = $i < 0 ? 'required' : '';
                                        ?>
                                        <div id="recomendations_line_{{ $i }}" style="display:none">
                                            <div class="input-control">
                                                <div>
                                                    <div class="caption max-w300">שם פרטי + שם משפחה</div>
                                                    <input type="text"
                                                        name="recomendations_name_{{ $i }}" class="max-220"
                                                        placeholder="">
                                                </div>
                                            </div>
                                            <div class="input-control">
                                                <div>
                                                    <div class="caption max-w300">מקום עבודה</div>
                                                    <input type="text" name="recomendations_work_place[]"
                                                        class="max-220" placeholder="">
                                                </div>
                                            </div>
                                            <div class="input-control">
                                                <div>
                                                    <div class="caption max-w300">תפקיד / מקצוע</div>
                                                    <input type="text" name="recomendations_role[]" class="max-220"
                                                        placeholder="">
                                                </div>
                                            </div>
                                            <div class="input-control inline">
                                                <label>
                                                    <div class="caption max-w180">מספר נייד / מספר טלפון</div>
                                                    <input type="text" name="recomendations_phone[]"
                                                        pattern="^[0-9]+$" minlength="7" maxlength="7"
                                                        class="max-130">
                                                </label>
                                                <select class="max-65 phn" name="recomendations_mobile_phone1_select[]"
                                                    style="margin-right: -23px">
                                                    <option value="050">050</option>
                                                    <option value="052"> 052</option>
                                                    <option value="053"> 053</option>
                                                    <option value="054"> 054</option>
                                                    <option value="055"> 055</option>
                                                    <option value="057"> 057</option>
                                                    <option value="058"> 058</option>
                                                </select>
                                            </div>
                                            <div class="input-control btn-descr file-block"
                                                style="transform:translateY(-8px)">
                                                <div class="caption max-w300">אנא צרף תעודה רלוונטית <span
                                                        style="margin-right: 5px;" data-toggle="tooltip"
                                                        title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                            class="fas fa-info-circle" aria-hidden="true"></i></span>
                                                </div>

                                                <?php //$key = $i + 13; $file = $form_file[$key];
                                                ?>

                                                <input type="hidden" name="vals" class="formvalsfile"
                                                    value="{{ $key }}" />
                                                <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                                    value="{{ $key }}" />
                                                <?php for($z=0; $z<10; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		
	}
	
	$required_val = $file['required'];
								
							
       
        ?>
                                                <div id="add_file_line_{{ $key }}" class="add_file_line"
                                                    {{ $style }}>


                                                    <div style="display:flex;flex-direction:row;">
                                                        <div class="upload-block">
                                                            <a href="#" id="rcfile-upload-{{ $key }}"
                                                                class="rm" style="display:none"
                                                                onclick="removeFile(this,'{{ $key }}');return false;"><i
                                                                    class="trash-icon"></i></a>


                                                            <input id="{{ $key }}" type="text" disabled
                                                                class="btn-input-upload"
                                                                value="אנא צרף תעודה רלוונטית" />
                                                            <label for="cfile-upload-{{ $key }}"
                                                                class="btn-upload ">
                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                    xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                    width="19px" height="13px"
                                                                    style="transform: scale(0.8)  translateY(4px);">
                                                                    <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                                        d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                                </svg>
                                                                <span style="margin-top:-2px">

                                                                    בחר קובץ
                                                                </span>

                                                            </label>
                                                            {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
									onchange="fileChange(this)"
									accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword"/> --}}
                                                            <input id="cfile-upload-{{ $key }}"
                                                                type="file" name="file[{{ $key }}]"
                                                                onchange="fileChange(this)" accept="application/pdf"
                                                                {{ $required_val }} />

                                                        </div>
                                                        <div class="aline">
                                                            <button type="button" class="addbutton"
                                                                onclick="showLineFile(this)"
                                                                style="width:30px; height:30px; padding:0;">
                                                                <img src="/img/icons/plus.png" />

                                                            </button>
                                                        </div>

                                                    </div>

                                                </div>
                                                <?php } ?>

                                            </div>
                                            <div class="aline" style="flex-direction: row-reverse">
                                                <a href="#" class="closebtn" style="transform:translateY(-40px)"
                                                    onclick="closeLine(this)"><img src="/img/close-lg.png" /></a>
                                            </div>

                                        </div>
                                    @endfor
                                </div>
                            <div class="aline" style="flex-direction: row-reverse">
                                <button type="button" class="addbutton leftbtn" onclick="showLine()">
                                    <img src="/img/icons/plus.png" />
                                    הוסף שורה
                                </button>
                            </div>
                            <br />
                            <div>
                                <div class="header_line faind_line">
                                    צירוף מסמכים
                                </div>
                                <div class="input-control btn-descr file-block" style="transform:translateY(-8px)">
                                    <div class="caption bold max-w300">אנא צרף קורות חיים <span
                                            style="margin-right: 5px;" data-toggle="tooltip"
                                            title="סוגי מסמכים מותרים הם: jpg, jpeg, doc, docx ו pdf עד 20 mb"><i
                                                class="fas fa-info-circle" aria-hidden="true"></i></span></div>

                                    <?php //$key = 2; $file = $form_file[$key];
                                    ?>
                                    <?php $key = 333; ?>
                                    <input type="hidden" name="vals" class="formvalsfile"
                                        value="{{ $key }}" />
                                    <input type="hidden" name="valsstatic" class="formvalsfilestatic"
                                        value="{{ $key }}" />
                                    <?php for($z=0; $z<10; $z++,$key++){
	$file = $form_file[$key];
	
	if($z==0){
		$style= "";
	}else{
		$style = "style=display:none";
		
	}
	
	$required_val = $file['required'];
								
							
       
        ?>
                                    <div id="add_file_line_{{ $key }}" class="add_file_line"
                                        {{ $style }}>


                                        <div style="display:flex;flex-direction:row;">
                                            <div class="upload-block">
                                                <a href="#" id="rcfile-upload-{{ $key }}"
                                                    class="rm" style="display:none"
                                                    onclick="removeFile(this,'{{ $key }}');return false;"><i
                                                        class="trash-icon"></i></a>
                                                <input id="{{ $key }}" type="text" disabled
                                                    class="btn-input-upload" value="אנא צרף תעודה רלוונטית" />
                                                <label for="cfile-upload-{{ $key }}" class="btn-upload ">
                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="19px"
                                                        height="13px" style="transform: scale(0.8)  translateY(4px);">
                                                        <path fill-rule="evenodd" fill="rgb(128, 184, 57)"
                                                            d="M14.537,4.008 L-0.000,4.008 L3.496,13.001 L17.666,13.001 L14.537,4.008 ZM19.000,-0.001 L13.480,-0.001 L12.375,2.000 L3.508,2.000 L3.510,2.985 L15.230,2.985 L18.725,13.001 L19.000,13.001 L19.000,-0.001 Z" />
                                                    </svg>
                                                    <span style="margin-top:-2px">

                                                        בחר קובץ
                                                    </span>

                                                </label>
                                                {{-- <input id="cfile-upload-{{$key}}" type="file" name="file[{{$key}}]"
										onchange="fileChange(this)"
										accept="application/pdf, image/jpeg, image/jpg, .doc,.docx, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword" {{$file['required']}}/> --}}
                                                <input id="cfile-upload-{{ $key }}" type="file"
                                                    name="file[{{ $key }}]" onchange="fileChange(this)"
                                                    accept="application/pdf" {{ $file['required'] }} />

                                            </div>
                                            <div class="aline">
                                                <button type="button" class="addbutton" onclick="showLineFile(this)"
                                                    style="width:30px; height:30px; padding:0;">
                                                    <img src="/img/icons/plus.png" />

                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="faind_line_small_div">
                                <div class="header_line faind_line">
                                    קרובי משפחה
                                </div>
                                <div class="faind_line_small">
                                    קרובי משפחה בין עובדי הרשות ונבחריה ( "קרובי משפחה" בהגדרתם בנוהל מס' 24.0202 "העסקת
                                    קרובי
                                    משפחה" ):
                                </div>
                                <div class="faind_line_small">
                                    <b><u>הגדרת קרבת משפחה:</u></b>
                                </div>
                                <div class="faind_line_small">
                                    "קרוב" – בן-זוג, הורה, בן, בת, אח, אחות, גיס, גיסה, דוד, דודה, בן דוד, בת דוד, בן דודה,
                                    בת
                                    דודה, בן אח, בת אח, בן אחות, בת אחות, חותן, חותנת, חם, חמות, חתן, כלה, נכד או נכדה,
                                    לרבות
                                    חורג או מאומץ, ובני זוגם.
                                </div>
                                <div>
                                    <div class="faind_line_small">
                                        <label class="radio">
                                            <input type="radio" name="nearness" value="yes" required="true"
                                                id="nearness_yes">
                                            <span class="virtual"></span>
                                            <span class="caption">יש לי קרוב משפחה בין עובדי הרשות ונבחריה</span>
                                        </label>
                                    </div>
                                    <div class="faind_line" style="margin-bottom: 0" data-show_type="nearness_yes">
                                        <div id="relatives_block">
                                            <div id="relatives_line">
                                                <div class="input-control inline">
                                                    <div>
                                                        <div class="caption max-w180" style="margin-right:10px">שם</div>
                                                        <input type="text" name="relative_name[]" required=""
                                                            class="mmax-220" placeholder="">
                                                    </div>
                                                </div>
                                                <div class="input-control inline">
                                                    <div>
                                                        <div class="caption max-w180">יחס קרבה</div>
                                                        <select class="max-220" name="relative_distance[]"
                                                            style="margin-right: 1px">
                                                            <option value="הורה">הורה</option>
                                                            <option value="בן / בת">בן / בת</option>
                                                            <option value=" סב / סבתא">אחות סב / סבתא</option>
                                                            <option value="אח">אחיין / אחיינית</option>
                                                            <option value="דוד">אח / אחות</option>
                                                            <option value="גיס / גיסה (לרבות בני זוגם)">גיס / גיסה (לרבות
                                                                בני
                                                                זוגם)</option>
                                                            <option value="דוד / דודה (לרבות בני זוגם)">דוד / דודה (לרבות
                                                                בני
                                                                זוגם)</option>
                                                            <option value="חותן / חותנת">חותן / חותנת</option>
                                                            <option value="חם / חמות">חם / חמות</option>
                                                            <option value="חתן / כלב">חתן / כלה</option>
                                                            <option value=" נכד / נכדה"> נכד / נכדה</option>
                                                            <option value=" בן/בת זוג"> בן/בת זוג</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="input-control inline">
                                                    <div>
                                                        <div class="caption max-w180">תיאור התפקיד</div>
                                                        <input type="text" name="relative_name_d1[]" required=""
                                                            class="max-660" style="width:710px" placeholder="">
                                                    </div>
                                                </div>
                                                <a href="#" class="closebtn" style='display:none;padding:10px'
                                                    onclick="closeLine(this)"><img src="/img/close-lg.png" /></a>

                                            </div>
                                        </div>
                                        <button type="button" class="addbutton"
                                            onclick="dublibe('relatives_block','relatives_line')">הוסף
                                        </button>
                                    </div>
                                    <div class="faind_line_small">
                                        <label class="radio">
                                            <input type="radio" name="nearness" value="no" required="true">
                                            <span class="virtual"></span>
                                            <span class="caption">אין לי קרוב משפחה בין עובדי הרשות ונבחריה</span>
                                        </label>
                                    </div>
                                </div>

                                <div>
                                    <div class="header_line faind_line">
                                        <b><u>מניעת ניגוד עניינים</u></b>
                                    </div>

                                    <div style="display: flex;flex-direction: row; align-items: center;">

                                        <div>
                                            <div class="faind_line_small">
                                                <label class="radio">
                                                    <input type="radio" name="form5_nigud" value="no">
                                                    <span class="virtual"></span>
                                                    <span>הריני לאשר כי אין לי ניגוד עניינים ואינני עומד להימצא במצבים
                                                        העלולים
                                                        לגרום לו להימצא במצב של ניגוד עניינים, ובכלל זה זיקה פוליטית, כלכלית
                                                        או
                                                        אישית לראש הרשות המקומית, לחבר מועצה ברשות המקומית או לעובד שדרגתו
                                                        אחת
                                                        משתי הדרגות הגבוהות ביותר ברשות המקומית.</span>
                                                </label>
                                            </div>
                                            <div class="faind_line_small">
                                                <label class="radio">
                                                    <input type="radio" name="form5_nigud" id="form5_nigud_yes"
                                                        value="yes">
                                                    <span class="virtual"></span>
                                                    <span> ככל ישנו ניגוד עניינים.</span>
                                                </label>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="faind_line" id='fform5' style="margin-bottom: 0;display:none"
                                        data-show_type="form5_nigud_yes">
                                        <div class="input-control">
                                            <div>
                                                <div class="caption max-w300">אנא פרט:
                                                </div>
                                                <input type="text" name="form5_nigud_text" id="form5_nigud_text"
                                                    required="" class="max-660" style="width:710px"
                                                    placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="header_line faind_line">
                                        <b><u>ייצוג הולם ושוויון הזדמנויות בעבודה</u></b>
                                    </div>
                                    <div class="faind_line_small">
                                        הרשות מקנה עדיפות לזכאים לכך על פי דין, כדי לקדם את עקרונות הייצוג ההולם ושוויון
                                        ההזדמנויות בעבודה. אם את/ה נמנים עם אחת הקבוצות הבאות סמנ/י X במקום המתאים:
                                    </div>
                                    <div style="display: flex;flex-direction: row; align-items: center;">
                                        <a href="#" class="rm" onclick="resetRadio();return false;"><i
                                                class="trash-icon"></i></a>
                                        <div>
                                            <div class="faind_line_small">
                                                <label class="radio">
                                                    <input type="radio" name="form3_ch2" value="no">
                                                    <span class="virtual"></span>
                                                    <span>אני או אחד מהוריי נולדנו באתיופיה.</span>
                                                </label>
                                            </div>
                                            <div class="faind_line_small">
                                                <label class="radio">
                                                    <input type="radio" name="form3_ch2" id="form3_ch2"
                                                        value="yes">
                                                    <span class="virtual"></span>
                                                    <span>אני אדם עם מגבלות כמשמעו בצו ההרחבה לעידוד והגברת תעסוקה של אנשים
                                                        עם
                                                        מוגבלות.</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faind_line" id='fform3' style="margin-bottom: 0;display:none"
                                        data-show_type="form3_ch2">
                                        <div class="input-control">
                                            <div>
                                                <div class="caption max-w300">אם כן, אנא פרט אילו התאמות נגישות נדרשות
                                                    לצורך
                                                    מילוי תפקידך
                                                </div>
                                                <textarea type="text" name="form3_text" class="max-880 height-2lines" placeholder=""></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {{-- <div class="header_line faind_line">
                                    <b><u>הצהרת המועמד</u></b>
                                </div>
                                <div class="faind_line_small">
                                    אני מסכים/ה לעמוד בבדיקות הערכה/מיון/מהימנות ו/או מבדקי התאמה נוספים שהעירייה תקבע במידה
                                    ויידרש.<br>
                                    ידוע לי שלא תהיה התייחסות לטופס שלא מולא במלואו ולא הוגשו כל המסמכים הנדרשים.<br>
                                    מודגש כי רק מי שעומד/ת בכל תנאי הסף ומגיש את כלל המסמכים תישקל מועמדותו/ה לתפקיד
                                    שב{{ $textChange }}.<br>
                                </div> --}}
                                {{-- <div class="faind_line_small">
                                    <b><u>מנהלה</u></b><br>
                                    <ul>
                                        <!--<li>במקרה של ריבוי מועמדים תהא העירייה רשאית לבחור מבין המועמדים עד 7 מועמדים מתאימים למשרה, אשר הם בלבד מתוך כל המועמדים יוזמנו להופיע בפני ועדת המכרזים. הבחירה תעשה על יסוד המסמכים בלבד ו/או על יסוד ראיון מוקדם עם המועמדים ו/או חלקם, ע"פ שיקול דעתה הבלעדי של העירייה.</li>-->
                                        <li>הבחירה תעשה על יסוד המסמכים בלבד ו/או על יסוד ראיון מוקדם עם המועמדים ו/או חלקם,
                                            ע"פ
                                            שיקול דעתה הבלעדי של העירייה.</li>
                                        <li>בהתאם לחוק שיווין זכויות לאנשים עם מגבלות תינתן העדפה במשרות הנ"ל למועמדים
                                            העונים על
                                            הגדרת החוק ועונים על דרישות התפקיד.</li>
                                        <li>לפי סעיף 173ב' לפקודת העירייה תינתן עדיפות למועמדים בני העדה האתיופית העונים על
                                            דרישות התפקיד.</li>
                                        <li>במידה ונשלחה דרישה להמצאת מסמכים נוספים הרי שהמועמדות תיבדק רק אם יתקבלו המסמכים
                                            תוך
                                            5 ימים מתאריך הוצאת המכתב ובו בקשה להשלמת מסמכים חסרים, אחרת תראה המועמדות
                                            כמבוטלת.
                                        </li>
                                    </ul>
                                </div> --}}
                                {{-- <div class="faind_line_small" style="font-weight: bold;">
                                    הריני מצהיר בזאת שכל הפרטים שמסרתי לעיל נכונים וידוע לי כי מסירת פרטים / מסמכים שאינם
                                    נכונים
                                    מהווה עבירה על פי חוק.
                                </div>
                                <div class="faind_line_small">
                                    (אם יתברר, בזמן כלשהו, כי הצהרתי זו אינה נכונה, אני מתחייב/ת להפסיק את עבודתי במועצה מיד
                                    עם
                                    קבלת הודעה מתאימה ממנהל משאבי אנוש; ובמקרה זה יראו אותי כמי שהתפטר/ה מעבודתו/ה במועצה על
                                    כל
                                    המשתמע מכך, וידוע לי כי במקרה זה לא אהיה זכאי/ת לפיצויי פיטורים או לדבר אחר כלשהו, וכי
                                    אין
                                    האמור לעיל גורע מסמכויות או מזכויות הרשות לנקוט נגדי כל צעד חוקי נוסף בגין מסירת הצהרה
                                    בלתי
                                    נכונה.)
                                </div> --}}
                            </div>
                            <div class="faind_line mi100" style="display: flex;flex-direction: column">
                                <br>
                                <div class="signature-container"
                                    style="text-align: left;float: left; padding-bottom: 50px;">
                                    <span class="caption" style="vertical-align: bottom;">חתימה:</span>
                                    <div class="signature-content" style="position: relative;">
                                        <canvas class="signature" width="200" height="140"
                                            style="height: 140px;touch-action: none;z-index: 1;position: relative;"></canvas>
                                        <span class="plesh_sig">
                                            נא תחתום כאן עם העכבר
                                        </span>
                                        <img class="signature-eraser" src="{{ asset('/front/img/eraser.png') }}" />
                                    </div>
                                    <div class="img"></div>
                                    <input class="signature-text" type="text" name="moth_sign" tabindex="-1"
                                        required
                                        style="opacity: 0; width: 0.1px; height: 0.1px; margin: 0!important; display: inline-block;">
                                </div>
                                <div class="center  hidden-pdf" style="display:flex;justify-content:center">

                                    <button class="btn btn-lg btn-default success bottom-btn-second" id="reportSendBtn"
                                        type="submit">
                                        שלח
                                    </button>
                                </div>
                                <div class="submit-error-msg"></div>
                            </div>
    </form>

    <script language="JavaScript">
        function goback() {
            history.back();
        }

        function checksubmit() {
            var rt0 = Array.from(document.getElementsByTagName("textarea"));
            var rt = Array.from(document.getElementsByTagName("input"));
            rt = rt.concat(rt0);
            // rt={...rt,...rt0};
            console.log('chk sub', rt);

            // var doc=document.getElementsByName("form");
            // console.log(doc);
            for (let i = 0; i < rt.length; i++) {
                // console.log(rt[i]);
                rt[i].required = false;
            }
            var email = document.getElementsByName("email")[0];

            window.email = email ? email.value : '';


        }

        function onsubmit() {
            console.log('submitted!');
            //  window.location.href = '/page2/{{ $tid }}';
        }
    </script>
@endsection
