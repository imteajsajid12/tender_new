@extends('forms.layouts.protocol-header')
@section('content')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<?php
$tenderid = 0;
if ($_GET['tenderid'] != '') {
	$tenderid = $_GET['tenderid'];
}
$tname = '';
if ($_GET['tname'] != '') {
	$tname = $_GET['tname'];
}
?>

<style>
	.free-input{
		border: none;
		border-bottom: 1px solid;
		outline: none;
	}
	.main-footer{
		width: 100%;
		padding-bottom: 20px !important;
	}
	.hidden-pdf:first-child{
		margin-top: 3rem !important;
	}
</style>		
				@if (!$download)
				<a onclick="confirm('Did you save the form? Save the form first, otherwise no text or signature will be appeared in downloaded pdf')" class="btn btn-block btn-info d-print-none" href="{{ url()->full() }}&download">פרוקוקול PDF</a>
				@endif
				<input type="hidden" name="from_name" id="from_name" value="protocol"/>
				<div dir="rtl" class="text-center">
					<p class="h3" class="text-center font-weight-bold" style="color: #000080">פרוטוקול מכרז מס':{{ $tenderid }}</p>
				</div>
				<div class="text-right">
					<p class="h6">פרטי המשרה:</p>
					<p>לתפקיד: {{ $tname }} </p>
					<p>מינהל:  {{ $tender->brunch }}</p>

				</div>
				<div class="row" dir="rtl">
					<div class="col-auto">
						<div class="w-auto">
							<h4>רשימת חברי וועדה:</h4>
		
							<table>
								<tbody>
									@foreach ($tender->decisionMaker as $dm)
										<tr><td>{{ $loop->iteration }}</td>
										<td>{!! nl2br($dm->decision_maker) !!}</td></tr>
									@endforeach
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<form class="text-right" method="POST" action="{{ route('saveDecision',$tenderid) }}">
				<div class="row" dir="rtl" style="font-size: 13px;">
					<div class="col-auto">
						<div class="w-12">
							<h4>רשימת מועמדים:</h4>
		
							<table>
								<thead>
									<th>#</th>
									<th>שם</th>
									@if (!$download)	
									<th>קורות חיים</th>
									@endif
									<th>הופיע</th>
									<th>לא הופיע</th>
								</thead>
								<tbody>
									@foreach ($tender->applications as $application)
									<tr>
										<th>{{ $loop->iteration }}</th>
										<th>{{ $application->applicant_name }}</th>
										@if (!$download)	
										<th>
											@foreach ($application->files as $file)
											@if (str_ends_with($file->file_name,'קורות חיים') || $file->is_cv)
												<a target="_blank" href="{{ asset('upload/'.$file->url) }}">קישור לקורות חיים</a>
												@break
											@endif
											@endforeach
										</th>
										@endif
										<th>
											<input @checked($application->is_appeared) name="appeared[{{ $application->id }}]" type="radio" value="1">
										</th>
										<th>
											<input @checked(!$application->is_appeared) name="appeared[{{ $application->id }}]" type="radio" value="0">
										</th>
									</tr>
									@endforeach
								</tbody>
							</table>
						</div>
					</div>
					
						@csrf
						<input type="hidden" value="{{ $tenderid }}" name="tender_id">
					<div class="col-12">
						החלטת הוועדה בתאריך: <input name="decision_on" value="{{ $tender?->decision?->decision_on }}" type="text" class="free-input">
					</div>
					
					@php
						$select_dec = json_decode($tender?->decision?->select_dec) ?? [];
					@endphp
					<div class="text-right"  dir="rtl">
						<ul style="">
							<li>
								<input type="checkbox" @checked(in_array(1, $select_dec)) name="select_dec[1]" value="1" id="">הוועדה החליטה לבחור במועמדים הבאים לסבב ראיון נוסף, לאחר בחינת התאמה לתפקיד: <input value="{{ $tender?->decision?->suitable_pos }}" name="suitable_pos" type="text" class="free-input">
							</li>
							<li>
								<input type="checkbox" @checked(in_array(2, $select_dec)) name="select_dec[2]" value="2" id="">הוועדה החליטה לבחור במועמד/ת  או  מועמדים/ות <input value="{{ $tender?->decision?->proposed_pos }}" name="proposed_pos" type="text" class="free-input">
								למשרה המוצעת. כמו כן, בוחרת הוועדה את המועמד/ת<input value="{{ $tender?->decision?->second_pos }}" name="second_pos" type="text" class="free-input">  כמועמד/ת שני/ה  ואת המועמד/ת <input value="{{ $tender?->decision?->third_pos }}" name="third_pos" type="text" class="free-input"> כמועמד/ת שלישי/ת.
							</li>
							<li>
								<input type="checkbox" @checked(in_array(3, $select_dec)) name="select_dec[3]" value="3" id="">הוועדה החליטה שאף אחד מבין המועמדים אינו מתאים למשרה המוצעת.
							</li>
						</ul>
						
					</div>

					<div class="text-right" dir="rtl">
						<div class="">חתימת חברי וועדה</div>
						<table>
							<tbody>
								@foreach ($tender->decisionMaker as $dm)
									<tr><td>{{ $loop->iteration }}</td>
									<td>{!! nl2br($dm->decision_maker) !!}</td>
									<td class="w-50">
										<div class="signature-container"
                                    style="text-align: left;float: left; padding-bottom: 50px;">
                                    <span class="caption" style="vertical-align: bottom;">חתימה:</span>
                                    <div class="signature-content" style="position: relative;">
                                        <canvas class="signature" width="200" height="140"
                                            style="height: 140px;touch-action: none;z-index: 1;position: relative;"></canvas>
                                        <span class="plesh_sig">
                                            נא תחתום כאן עם העכבר
                                        </span>
                                        <img class="signature-eraser" src="{{ asset('/front/img/eraser.png') }}" />
                                    </div>
                                    <div class="img" @style([
										'display:none' => !$dm->signature,
										'display:block' => $dm->signature
									])>
										@if ($dm->signature)	
										<img src="{{ $dm->signature }}" alt="" srcset="">
										@endif
									</div>
                                    <input class="signature-text" value="{{ $dm->signature }}" type="text" name="moth_sign[{{ $dm->id }}]" tabindex="-1"
                                        required
                                        style="opacity: 0; width: 0.1px; height: 0.1px; margin: 0!important; display: inline-block;">
                                </div>
									</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
					<div style="" class="w-100" dir="rtl">
						@if (!$download)	
						<button style="width: 100%;font-size: 1.2em;" class="btn btn-lg btn-default success d-print-none" id="reportSaveBtn" type="submit">שמור מסמך</button>
						<br>
						@endif
						<div class="submit-error-msg"></div>
					</div>
					</form>
				</div>
				
@endsection