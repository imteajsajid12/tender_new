@if (!isset($download))
<div class="form-group d-print-none">
    <label for="">שם התבנית</label>
    <input class="form-control" name="template_name" id="template_name" type="text" value="מועצה מקומית קריית ארבע חברון (ליד גדרה)">
</div>
@endif