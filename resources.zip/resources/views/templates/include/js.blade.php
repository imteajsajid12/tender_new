<script>
    // $(document).ready(()=>{
    //     syscTextAreaHeight()
    // })

    // function syscTextAreaHeight(e=null){
    //     if(e!=null){
    //         autosize($(e)[0]);
    //     }


    //     autosize($('textarea'));
    // }
    // $(document).on('click change input', 'textarea', function(event) {
    //     /* Act on the event */
    //     syscTextAreaHeight(this)
    // });

    
</script>