<!DOCTYPE html>
<div class="mt-0">
    <div class="page-header-title pt-4 bg-white text-center font-weight-bold" style="background-image: url('{{ asset('img/templates/temp1-footer.jpg') }}');    background-position: center;
background-repeat: repeat;
background-size: cover; height:@isset($isView) 185px @else 125px @endisset">
{{-- <img src="{{ asset('img/templates/temp1-footer.jpg') }}" alt=""> --}}
    </div>
</div>