<html>
<body dir="rtl" style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #5d5c5c;">
<div style="width: 800px">
    <h2 style="color:red"><?php echo $body ; ?></h2>
</div>
</body>
</html>
