<style type="text/css">
            .dot-separator {
                display: inline-block;
                width: 10px;
                height: 10px;
                border-radius: 50%;
                background-color: rgb(142, 186, 14);
                margin: 0 10px;
                margin-bottom: 2px;
            }
</style>
            
</main>
<!--
<footer style="text-align: center;line-height: 30px;font-size: 18px;overflow: hidden;">
      <div> בניין העירייה <i class="dot-separator"></i> קניון נעימי, דרך רבין 2, בית שמש <i class="dot-separator"></i> ט.ל: 1-700-500-521 <i class="dot-separator"></i> פקס: 02-9909741 
      </div>
      <div style="border-top: 2px solid rgb( 171, 204, 75 );text-transform: uppercase;">
		  <div class="col-xs-12">
			  <a href="#">Bshemesh@mgar.co.il</a>
			  <i class="dot-separator"></i>
			  <a href="#">www.betshemesh.muni.il</a>
		  </div>
	</div>
    </footer>
-->
</body>
</html>
