<nav class=" d-none d-md-block bg-light sidebar">
    <div class="sidebar-sticky">
		<div style="display: flex; flex-direction: row;">
			<div>
        		<img src="{{asset('img/right-side.jpg')}}">
			</div>
			<div>
				<img src="{{asset('img/right-side-bottom.jpg')}}">
			</div>
		</div>
    </div>
</nav>