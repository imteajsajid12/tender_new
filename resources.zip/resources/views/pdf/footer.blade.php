<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style type="text/css">
            .rand{
              display: inline-block;
              width: 8px;
              height: 8px;
              background: #8eba0e;
              border-radius: 50%;
              margin: 0 10px;
            }
            body{
                direction: rtl;
                margin: auto;
                font-size: 18px;
                padding: 0;
                position: relative;
                font-family: 'Open Sans Hebrew';
            }
    </style>
</head>
<body>
    <footer style="text-align: center;line-height: 30px;font-size: 18px;overflow: hidden;">
      <div> מרכז כפרי נהורה <i class="rand"></i> ד.נ לכיש דרום, מיקוד 79340 <i class="rand"></i> ט.ל: 03-5027417</a> <i class="rand"></i> WWW.LACHISH.ORG.IL
      </div>
      <div style="border-top: 2px solid rgb( 171, 204, 75 );text-transform: uppercase;">
          <span class="text">אחוזם <span class="dot-d">*</span> אליאב <span class="dot-d">*</span> אמציה <span class="dot-d">*</span> בני-דקלים <span class="dot-d">*</span> זוהר <span class="dot-d">*</span> יד נתן <span class="dot-d">*</span> כרמי-קטיף <span class="dot-d">*</span> לכיש <span class="dot-d">*</span> מנוחה <span class="dot-d">*</span> נטע <span class="dot-d">*</span> נהורה <span class="dot-d">*</span> נוגה <span class="dot-d">*</span> ניר ח"ן <span class="dot-d">*</span> עצם <span class="dot-d">*</span> שדה דוד <span class="dot-d">*</span> שדה משה <span class="dot-d">*</span> שחר <span class="dot-d">*</span> שקף <span class="dot-d">*</span> תלמים </span>
      </div>
    </footer>
</body>
</html>
